
import { Link } from "react-router-dom";
import { ArrowRight, Clock3 } from "lucide-react";

export default function BlogCard({ blog }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-lg border border-slate-200 bg-white transition duration-300 hover:-translate-y-1 hover:shadow-xl">
      <Link
        to={`/health-library/blogs/${blog.slug}`}
        className="block h-48 overflow-hidden bg-slate-100"
      >
        <img
          src={blog.image}
          alt={blog.title}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      </Link>

      <div className="flex flex-1 flex-col p-5">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
          {blog.category}
        </span>

        <h3 className="mt-3 line-clamp-2 text-lg font-bold leading-7 text-[#173b56]">
          <Link
            to={`/health-library/blogs/${blog.slug}`}
            className="transition hover:text-teal-700"
          >
            {blog.title}
          </Link>
        </h3>

        <p className="mt-3 line-clamp-3 flex-1 text-sm leading-6 text-slate-500">
          {blog.excerpt}
        </p>

        <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4">
          <span className="flex items-center gap-1.5 text-xs text-slate-500">
            <Clock3 size={14} />
            {blog.readTime}
          </span>

          <Link
            to={`/health-library/blogs/${blog.slug}`}
            className="inline-flex items-center gap-2 text-sm font-bold text-[#23658a] hover:text-teal-700"
          >
            Read Article <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </article>
  );
}












// import { ArrowRight, Clock3 } from "lucide-react";
// import { Link } from "react-router-dom";

// export default function BlogCard({ blog }) {
//   return (
//     <article className="group overflow-hidden rounded-2xl border border-line bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg">
//       <Link to={`/health-library/blogs/${blog.slug}`} className="block overflow-hidden">
//         <img src={blog.image} alt="" loading="lazy" className="h-48 w-full object-cover transition duration-500 group-hover:scale-105 sm:h-52" />
//       </Link>
//       <div className="p-5">
//         <p className="text-xs font-bold tracking-[.14em] text-royal">{blog.category}</p>
//         <h3 className="display-font mt-2 text-lg font-bold leading-snug text-heading">{blog.title}</h3>
//         <p className="mt-2 line-clamp-3 text-sm leading-6 text-ink">{blog.description}</p>
//         <div className="mt-4 flex items-center justify-between gap-3">
//           <span className="inline-flex items-center gap-1 text-xs text-ink/70"><Clock3 size={14}/>{blog.readTime}</span>
//           <Link to={`/health-library/blogs/${blog.slug}`} className="inline-flex items-center gap-2 text-sm font-bold text-royal hover:text-sky">Read article <ArrowRight size={16}/></Link>
//         </div>
//       </div>
//     </article>
//   );
// }
