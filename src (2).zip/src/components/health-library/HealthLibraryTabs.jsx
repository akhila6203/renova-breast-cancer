
import { useState } from "react";
import { BookOpen, PlayCircle, CircleHelp, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

import {
  healthCategories,
  healthBlogs,
  healthVideos,
  healthFaqs,
} from "../../data/healthLibraryData";

import BlogCard from "./BlogCard";
import FaqAccordion from "./FaqAccordion";

const tabs = [
  { id: "blogs", label: "Blogs", icon: BookOpen },
  { id: "videos", label: "Videos", icon: PlayCircle },
  { id: "faqs", label: "FAQs", icon: CircleHelp }
];

export default function HealthLibraryTabs({ initialTab = "blogs" }) {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [visibleVideos, setVisibleVideos] = useState(16);

  return (
    <section className="bg-[#f5f8fa] py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <span className="text-xs font-bold uppercase tracking-[2px] text-teal-700">
            Learn at your pace
          </span>
          <h2 className="mt-3 text-3xl font-bold text-[#173b56] sm:text-4xl">
            Explore Our Resources
          </h2>
          <p className="mt-3 text-base leading-7 text-slate-500">
            Read articles, watch educational videos and find answers to common questions.
          </p>
        </div>

        {/* All three tabs stay visible */}
        <div className="mx-auto mb-10 grid max-w-3xl grid-cols-3 gap-2 sm:gap-4">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const selected = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setActiveTab(tab.id)}
                className={`flex min-h-14 items-center justify-center gap-2 rounded-md border px-2 py-3 text-sm font-bold transition sm:text-base ${
                  selected
                    ? "border-[#23658a] bg-[#23658a] text-white shadow-md"
                    : "border-slate-200 bg-white text-[#173b56] hover:border-teal-600 hover:text-teal-700"
                }`}
              >
                <Icon size={18} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* BLOGS */}
        {activeTab === "blogs" && (
          <div>
            <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                  Latest Articles
                </span>
                <h3 className="mt-2 text-2xl font-bold text-[#173b56]">
                  Health Library Blogs
                </h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">
                  Helpful cancer education for patients and families.
                </p>
              </div>

              <Link
                to="/health-library/blogs"
                className="hidden items-center gap-2 rounded border border-[#23658a] px-5 py-3 text-sm font-bold text-[#23658a] transition hover:bg-[#23658a] hover:text-white sm:inline-flex"
              >
                All Blogs <ArrowRight size={16} />
              </Link>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {healthBlogs.slice(0, 8).map(blog => (
                <BlogCard key={blog.slug} blog={blog} />
              ))}
            </div>

            <div className="mt-8 text-center sm:hidden">
              <Link
                to="/health-library/blogs"
                className="inline-flex items-center gap-2 rounded border border-[#23658a] px-5 py-3 text-sm font-bold text-[#23658a]"
              >
                All Blogs <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        )}

        {/* VIDEOS */}
        {activeTab === "videos" && (
          <div>
            <div className="mb-7">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                Watch & Learn
              </span>
              <h3 className="mt-2 text-2xl font-bold text-[#173b56]">
                Videos & Patient Education
              </h3>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                Explore cancer education videos and treatment explainers.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {healthVideos.slice(0, visibleVideos).map((video, index) => (
                <article
                  key={`${video.title}-${index}`}
                  className="overflow-hidden rounded-lg border border-slate-200 bg-white"
                >
                  {video.youtubeId ? (
                    <div className="aspect-video">
                      <iframe
                        className="h-full w-full"
                        src={`https://www.youtube-nocookie.com/embed/${video.youtubeId}`}
                        title={video.title}
                        loading="lazy"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  ) : (
                    <div className="flex aspect-video items-center justify-center bg-[#eaf1f4]">
                      <PlayCircle size={48} className="text-[#23658a]" />
                    </div>
                  )}

                  <div className="p-4">
                    <span className="text-xs font-bold uppercase tracking-wide text-teal-700">
                      {video.category}
                    </span>
                    <h4 className="mt-2 font-bold leading-6 text-[#173b56]">
                      {video.title}
                    </h4>
                    {!video.youtubeId && (
                      <p className="mt-2 text-xs text-slate-500">
                        Video ID not added yet.
                      </p>
                    )}
                  </div>
                </article>
              ))}
            </div>

            {visibleVideos < healthVideos.length && (
              <div className="mt-9 text-center">
                <button
                  type="button"
                  onClick={() => setVisibleVideos(value => value + 8)}
                  className="inline-flex items-center gap-2 rounded bg-[#23658a] px-6 py-3 text-sm font-bold text-white transition hover:bg-teal-700"
                >
                  Load More Videos <ArrowRight size={17} />
                </button>
              </div>
            )}
          </div>
        )}

        {/* FAQS */}
        {activeTab === "faqs" && (
          <div>
            <div className="mb-8 text-center">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                Need clarity?
              </span>
              <h3 className="mt-2 text-2xl font-bold text-[#173b56] sm:text-3xl">
                Frequently Asked Questions
              </h3>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                Answers to common questions about cancer and cancer care.
              </p>
            </div>

            <FaqAccordion faqs={healthFaqs} />
          </div>
        )}
      </div>
    </section>
  );
}
