
export const healthCategories = [
  {
    slug: "cancer-basics",
    title: "Cancer Basics",
    subtitle: "Understand cancer from the beginning.",
    description:
      "Learn what cancer is, how abnormal cells develop, how tumours grow, and the difference between benign and malignant tumours. Explore cancer stages, grades, metastasis and the role of a multidisciplinary tumour board.",
    image:
      "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "What Is Cancer?",
      "How Cancer Develops",
      "Benign vs Malignant Tumours",
      "Understanding Cancer Stages",
      "Cancer Grades Explained",
      "How Cancer Spreads",
      "What Is Metastasis?",
      "What Is a Tumour Board?"
    ]
  },
  {
    slug: "cancer-symptoms",
    title: "Cancer Symptoms",
    subtitle: "Recognise warning signs and understand when to seek help.",
    description:
      "Cancer symptoms vary depending on the type and location of cancer. Learn about unusual lumps, unexplained bleeding, persistent pain, unexplained weight loss and other changes that may need medical evaluation.",
    image:
      "https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "Common Warning Signs",
      "Symptoms by Cancer Type",
      "Unusual Lumps and Swelling",
      "Unexplained Bleeding",
      "Unexplained Weight Loss",
      "Persistent Pain",
      "Symptoms That Should Not Be Ignored",
      "Can Cancer Have No Early Symptoms?"
    ]
  },
  {
    slug: "diagnosis-tests",
    title: "Diagnosis & Tests",
    subtitle: "Understand scans, biopsies and cancer testing.",
    description:
      "Explore how doctors investigate and diagnose cancer. Understand biopsies, pathology reports, CT, MRI and PET/CT scans, cancer staging, biomarkers, molecular testing and liquid biopsy.",
    image:
      "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "What Is a Cancer Biopsy?",
      "Understanding a Pathology Report",
      "CT vs MRI vs PET/CT",
      "How Is Cancer Staged?",
      "What Are Cancer Biomarkers?",
      "Molecular and Genomic Testing",
      "What Is a Liquid Biopsy?",
      "Immunohistochemistry",
      "Understanding PET Imaging"
    ]
  },
  {
    slug: "cancer-treatments",
    title: "Cancer Treatments",
    subtitle: "Explore cancer treatment approaches and technologies.",
    description:
      "Cancer treatment plans are individualised according to cancer type, stage, test results and patient needs. Explore the treatments and technologies available through RENOVA's existing Services and Treatments section.",
    image:
      "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "Surgery",
      "Chemotherapy",
      "Radiation Therapy",
      "Immunotherapy",
      "Targeted Therapy",
      "Hormone Therapy",
      "Precision Oncology",
      "Stem Cell Transplant",
      "CAR T-Cell Therapy",
      "TIL Therapy",
      "HIPEC",
      "Proton Therapy",
      "Robotic Surgery"
    ],
    externalPath: "/services",
    externalLabel: "Explore Treatments & Technology"
  },
  {
    slug: "latest-treatments-innovation",
    title: "Latest Treatments & Innovation",
    subtitle: "Discover advances in modern cancer care.",
    description:
      "Explore newer cancer treatment approaches, precision medicine, advanced radiation techniques, cell therapies, theranostics, digital pathology, AI-supported imaging and emerging cancer research.",
    image:
      "https://images.unsplash.com/photo-1581093458791-9d42e3c6e5f2?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "Antibody-Drug Conjugates",
      "Bispecific Antibodies",
      "CAR T-Cell Therapy",
      "TIL Therapy",
      "Radioligand Therapy",
      "Theranostics",
      "Tumour-Agnostic Therapy",
      "MR-Guided Adaptive Radiation",
      "Proton Therapy",
      "Digital Pathology and AI",
      "Liquid Biopsy and MRD",
      "Cancer Vaccines",
      "Established vs Investigational Treatments"
    ]
  },
  {
    slug: "risk-factors-prevention",
    title: "Risk Factors & Prevention",
    subtitle: "Learn about cancer risks and prevention.",
    description:
      "Understand factors associated with cancer risk, including tobacco, alcohol, obesity, UV exposure, infections and inherited risk. Learn about vaccination, screening and healthy lifestyle choices.",
    image:
      "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "Tobacco and Cancer",
      "Alcohol and Cancer Risk",
      "Obesity and Physical Activity",
      "UV Exposure",
      "HPV and Hepatitis Vaccination",
      "Family History",
      "Genetic Counselling",
      "Cancer Screening"
    ]
  },
  {
    slug: "living-with-cancer",
    title: "Living With Cancer",
    subtitle: "Support for everyday life during treatment.",
    description:
      "Find practical information about nutrition, fatigue, exercise, nausea, mental wellbeing, work, fertility, sexual health, pain management and supporting someone with cancer.",
    image:
      "https://images.unsplash.com/photo-1516307365426-bea591f05011?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "Nutrition During Treatment",
      "Managing Cancer Fatigue",
      "Exercise During Treatment",
      "Nausea and Appetite Changes",
      "Mental Health Support",
      "Work and Daily Life",
      "Sexual Health and Fertility",
      "Supporting Someone With Cancer",
      "Managing Cancer Pain"
    ]
  },
  {
    slug: "survivorship",
    title: "Survivorship",
    subtitle: "Guidance for life after cancer treatment.",
    description:
      "Learn about follow-up care, long-term effects, fear of recurrence, rehabilitation, returning to work, nutrition and emotional wellbeing after cancer treatment.",
    image:
      "https://images.unsplash.com/photo-1519823551278-64ac92734fb1?auto=format&fit=crop&w=1000&q=85",
    topics: [
      "Life After Cancer Treatment",
      "Follow-Up Care",
      "Fear of Cancer Recurrence",
      "Long-Term Treatment Effects",
      "Returning to Work",
      "Rehabilitation and Exercise",
      "Nutrition After Treatment",
      "Emotional Wellbeing"
    ]
  }
];

const blogTitles = [
  ["diagnosed-what-next", "Just Diagnosed With Cancer: What Should You Do Next?", "cancer-basics"],
  ["questions-for-oncologist", "Questions to Ask Your Oncologist", "cancer-basics"],
  ["second-opinion", "When Should You Consider a Second Opinion?", "cancer-basics"],
  ["tumour-board", "What Happens in a Tumour Board?", "cancer-basics"],
  ["understanding-biopsy", "Understanding a Cancer Biopsy", "diagnosis-tests"],
  ["pathology-report", "How to Understand a Pathology Report", "diagnosis-tests"],
  ["cancer-staging", "Cancer Staging Explained", "diagnosis-tests"],
  ["ct-mri-pet", "CT, MRI and PET Scans: What Is the Difference?", "diagnosis-tests"],
  ["molecular-testing", "Molecular Testing in Cancer", "diagnosis-tests"],
  ["liquid-biopsy", "What Is a Liquid Biopsy?", "diagnosis-tests"],
  ["biomarkers", "Cancer Biomarkers and Treatment Decisions", "diagnosis-tests"],
  ["chemotherapy-guide", "Chemotherapy: What Patients Should Know", "cancer-treatments"],
  ["immunotherapy-guide", "How Does Immunotherapy Work?", "cancer-treatments"],
  ["targeted-therapy", "Understanding Targeted Therapy", "cancer-treatments"],
  ["precision-oncology", "What Is Precision Oncology?", "cancer-treatments"],
  ["adc-treatment", "Antibody-Drug Conjugates Explained", "latest-treatments-innovation"],
  ["car-t", "CAR T-Cell Therapy: A Patient Guide", "latest-treatments-innovation"],
  ["til-therapy", "What Is TIL Therapy?", "latest-treatments-innovation"],
  ["bispecific-antibodies", "Bispecific Antibodies in Cancer Care", "latest-treatments-innovation"],
  ["theranostics", "Understanding Theranostics", "latest-treatments-innovation"],
  ["sbrt", "What Is Stereotactic Body Radiation Therapy?", "latest-treatments-innovation"],
  ["stereotactic-radiosurgery", "Stereotactic Radiosurgery Explained", "latest-treatments-innovation"],
  ["mr-guided-radiation", "What Is MR-Guided Radiation Therapy?", "latest-treatments-innovation"],
  ["proton-therapy", "Proton Therapy: What Patients Should Know", "latest-treatments-innovation"],
  ["cyberknife", "Understanding CyberKnife", "latest-treatments-innovation"],
  ["gamma-knife", "What Is Gamma Knife Treatment?", "latest-treatments-innovation"],
  ["robotic-surgery", "Robotic Surgery in Cancer Care", "cancer-treatments"],
  ["hipec", "What Is HIPEC?", "cancer-treatments"],
  ["nutrition-treatment", "Nutrition During Cancer Treatment", "living-with-cancer"],
  ["cancer-fatigue", "Managing Fatigue During Cancer Treatment", "living-with-cancer"],
  ["exercise-cancer", "Exercise During Cancer Treatment", "living-with-cancer"],
  ["mental-health", "Looking After Your Mental Health", "living-with-cancer"],
  ["caregiver-support", "How to Support Someone With Cancer", "living-with-cancer"],
  ["after-treatment", "What Happens After Cancer Treatment?", "survivorship"],
  ["recurrence-fear", "Coping With the Fear of Recurrence", "survivorship"],
  ["returning-to-work", "Returning to Work After Cancer", "survivorship"],
  ["long-term-effects", "Long-Term Effects After Cancer Treatment", "survivorship"],
  ["follow-up-care", "Why Follow-Up Care Matters", "survivorship"]
];

export const healthBlogs = blogTitles.map(
  ([slug, title, categorySlug], index) => {
    const category = healthCategories.find(
      (item) => item.slug === categorySlug
    );

    return {
      id: index + 1,
      slug,
      title,
      category: category?.title || "Cancer Care",
      categorySlug,
      excerpt: `Learn about ${title.toLowerCase()} through clear, patient-friendly cancer education and useful questions to discuss with your care team.`,
      image: category?.image || healthCategories[0].image,
      readTime: "5 min read",
      content: [
        `Understanding ${title.toLowerCase()} can help patients and families feel more prepared during cancer care.`,
        "Your doctor considers the cancer type, stage, test results, overall health and personal preferences when discussing treatment options.",
        "Ask your care team about the purpose of tests, possible benefits and risks, and the next steps in your care.",
        "This article is general educational information and does not replace advice from a qualified healthcare professional."
      ]
    };
  }
);

export const healthFaqs = [
  {
    question: "Is cancer one disease?",
    answer: "No. Cancer is a group of diseases involving abnormal cell growth. Different cancers behave differently and may need different treatments."
  },
  {
    question: "Does every lump mean cancer?",
    answer: "No. Many lumps are non-cancerous. A new, growing or persistent lump should be assessed by a doctor."
  },
  {
    question: "Can cancer occur without symptoms?",
    answer: "Yes. Some cancers may not cause noticeable symptoms in early stages. Screening may be recommended for certain people."
  },
  {
    question: "Is cancer always painful?",
    answer: "No. Cancer may not cause pain, especially in early stages. Persistent or unexplained pain should be discussed with a doctor."
  },
  {
    question: "What is the difference between benign and malignant tumours?",
    answer: "Benign tumours are non-cancerous. Malignant tumours are cancerous and can invade nearby tissues or spread."
  },
  {
    question: "What is cancer staging?",
    answer: "Staging describes the extent of cancer in the body and whether it has spread."
  },
  {
    question: "What is the difference between stage and grade?",
    answer: "Stage describes the extent of cancer. Grade describes how abnormal the cancer cells look under a microscope."
  },
  {
    question: "Is a biopsy always needed?",
    answer: "A biopsy is commonly used to confirm many cancer diagnoses, but the tests needed depend on the suspected cancer."
  },
  {
    question: "What is a pathology report?",
    answer: "It describes laboratory findings from tissue or cell samples and may include tumour type and grade."
  },
  {
    question: "What is the difference between CT, MRI and PET?",
    answer: "CT uses X-rays, MRI uses magnetic fields and radio waves, and PET provides information about metabolic activity."
  },
  {
    question: "What are cancer biomarkers?",
    answer: "Biomarkers are measurable features in tissue, blood or other samples that may help guide cancer care."
  },
  {
    question: "What is molecular testing?",
    answer: "Molecular testing looks for specific changes in cancer cells. In selected cancers, it can help guide treatment."
  },
  {
    question: "Is chemotherapy the same as radiation?",
    answer: "No. Chemotherapy uses medicines, while radiation therapy uses focused radiation to damage cancer cells."
  },
  {
    question: "What is immunotherapy?",
    answer: "Immunotherapy helps the immune system recognise or attack cancer. It is suitable for some cancers and patients."
  },
  {
    question: "What is targeted therapy?",
    answer: "Targeted therapy uses medicines that act on particular features or pathways involved in cancer growth."
  },
  {
    question: "Can treatment differ between two people with the same cancer?",
    answer: "Yes. Stage, tumour biology, biomarkers, health and treatment preferences can affect treatment decisions."
  },
  {
    question: "Can lifestyle changes prevent all cancers?",
    answer: "No. Healthy habits can reduce some risks, but they cannot prevent every cancer."
  },
  {
    question: "Does family history mean I will get cancer?",
    answer: "No. Family history may increase risk for some cancers, but it does not mean cancer is inevitable."
  },
  {
    question: "Can I exercise during cancer treatment?",
    answer: "Many people can do suitable physical activity, but the right level depends on treatment and health. Ask your care team."
  },
  {
    question: "What should I eat during treatment?",
    answer: "Nutrition needs vary. Your care team or clinical dietitian can help create a suitable plan."
  },
  {
    question: "What happens after cancer treatment?",
    answer: "Follow-up may include appointments, tests, rehabilitation and support for long-term effects."
  },
  {
    question: "When should I seek a second opinion?",
    answer: "You may consider one if you want to understand your diagnosis or treatment options better."
  }
];

export const healthVideos = [
  {
    title: "Understanding Cancer",
    category: "Cancer Basics",
    youtubeId: ""
  },
  {
    title: "Cancer Symptoms and Warning Signs",
    category: "Cancer Awareness",
    youtubeId: ""
  },
  {
    title: "Cancer Diagnosis and Tests",
    category: "Diagnosis & Tests",
    youtubeId: ""
  },
  {
    title: "Cancer Treatment Options",
    category: "Cancer Treatments",
    youtubeId: ""
  },
  {
    title: "Chemotherapy Explained",
    category: "Cancer Treatments",
    youtubeId: ""
  },
  {
    title: "Understanding Immunotherapy",
    category: "Cancer Treatments",
    youtubeId: ""
  },
  {
    title: "Radiation Therapy Explained",
    category: "Cancer Treatments",
    youtubeId: ""
  },
  {
    title: "Nutrition During Cancer Treatment",
    category: "Living With Cancer",
    youtubeId: ""
  },
  {
    title: "Managing Cancer-Related Fatigue",
    category: "Living With Cancer",
    youtubeId: ""
  },
  {
    title: "Cancer Screening and Prevention",
    category: "Prevention",
    youtubeId: ""
  },
  {
    title: "Understanding Cancer Biomarkers",
    category: "Diagnosis & Tests",
    youtubeId: ""
  },
  {
    title: "Life After Cancer Treatment",
    category: "Survivorship",
    youtubeId: ""
  },
  {
    title: "Supporting a Loved One With Cancer",
    category: "Caregiver Support",
    youtubeId: ""
  },
  {
    title: "Latest Advances in Cancer Care",
    category: "Innovation",
    youtubeId: ""
  },
  {
    title: "Questions to Ask Your Oncologist",
    category: "Patient Education",
    youtubeId: ""
  },
  {
    title: "Importance of Follow-Up Care",
    category: "Survivorship",
    youtubeId: ""
  },
  {
    title: "Cancer Surgery Explained",
    category: "Cancer Treatments",
    youtubeId: ""
  },
  {
    title: "Targeted Therapy Explained",
    category: "Cancer Treatments",
    youtubeId: ""
  },
  {
    title: "Emotional Wellbeing During Cancer Care",
    category: "Living With Cancer",
    youtubeId: ""
  },
  {
    title: "Healthy Habits and Cancer Prevention",
    category: "Prevention",
    youtubeId: ""
  },
  {
    title: "Understanding Genetic Testing",
    category: "Diagnosis & Tests",
    youtubeId: ""
  },
  {
    title: "Caregiver Support",
    category: "Caregiver Support",
    youtubeId: ""
  },
  {
    title: "Precision Oncology",
    category: "Latest Treatments",
    youtubeId: ""
  },
  {
    title: "Cancer Survivorship",
    category: "Survivorship",
    youtubeId: ""
  }
];




















// import { videos as existingVideos } from "./siteData";

// export const libraryCategories = [
//   { slug:"cancer-basics", title:"Cancer Basics", description:"Understand what cancer is, how it develops and how specialists describe it.", topics:["What Is Cancer?","How Cancer Develops","Benign vs Malignant Tumours","Understanding Cancer Stages","Understanding Cancer Grades","How Cancer Spreads","What Is Metastasis?","What Is a Tumour Board?"] },
//   { slug:"cancer-symptoms", title:"Cancer Symptoms", description:"Learn about warning signs, symptoms by cancer type and when to seek assessment.", topics:["Common warning signs that deserve medical assessment","Symptoms by cancer type","When a lump, bleeding, weight loss, pain or persistent symptom needs evaluation","Why some cancers cause no early symptoms"] },
//   { slug:"diagnosis-tests", title:"Diagnosis & Tests", description:"Explore the tests used to investigate, diagnose and stage cancer.", topics:["What Happens During a Cancer Biopsy?","Understanding Your Pathology Report","CT vs MRI vs PET/CT","What Is Cancer Staging?","What Are Cancer Biomarkers?","What Is Molecular Testing?","What Is Genomic Testing?","What Is a Liquid Biopsy?","What Is Immunohistochemistry?","How PET Imaging Helps in Cancer Care"] },
//   { slug:"cancer-treatments", title:"Cancer Treatments", description:"Patient-friendly explainers about treatment approaches. Explore available clinical services separately.", topics:["Cancer Surgery Explained","Chemotherapy Explained","Radiation Therapy Explained","Immunotherapy Explained","Targeted Therapy Explained","Hormone Therapy Explained","Precision Oncology","Stem Cell Transplantation","CAR T-Cell Therapy","TIL Therapy","Antibody-Drug Conjugates","Bispecific Antibodies","Theranostics","Interventional Oncology","HIPEC","Proton Therapy","Robotic Cancer Surgery"] },
//   { slug:"latest-treatments-innovation", title:"Latest Treatments & Innovation", description:"Understand emerging technologies and innovations, including what is established and what remains under investigation.", topics:["How Antibody-Drug Conjugates Are Changing Cancer Treatment","Bispecific Antibodies in Blood Cancers","CAR T-Cell Therapy: Who May Benefit?","TIL Therapy and Cellular Treatment for Solid Tumours","Radioligand Therapy and Theranostics","Tumour-Agnostic Targeted Therapy","Adaptive Radiation Therapy","MR-Guided Radiation Therapy","Proton Therapy: When Does It Matter?","Digital Pathology and AI-Assisted Workflows","Liquid Biopsy and Minimal Residual Disease Research","Cancer Vaccines: Prevention vs Treatment Vaccines","Artificial Intelligence in Cancer Imaging and Planning","Emerging Treatments: What Is Established vs Investigational?"] },
//   { slug:"risk-prevention", title:"Risk Factors & Prevention", description:"Learn about risk reduction, screening, vaccination and inherited risk.", topics:["Tobacco and cancer","Alcohol and cancer risk","Obesity and physical activity","UV exposure and skin cancer","HPV vaccination","Hepatitis vaccination and liver-cancer prevention","Family history and inherited cancer risk","Genetic counselling","Cancer screening by age and risk","Healthy lifestyle and cancer-risk reduction"] },
//   { slug:"living-with-cancer", title:"Living With Cancer", description:"Practical information for patients, families and caregivers during treatment.", topics:["Nutrition During Cancer Treatment","Managing Cancer-Related Fatigue","Exercise During Cancer Treatment","Managing Nausea and Appetite Changes","Mental Health After a Cancer Diagnosis","Working During Cancer Treatment","Sexual Health and Cancer","Fertility and Cancer Treatment","Supporting Someone With Cancer","Managing Pain and Other Symptoms"] },
//   { slug:"survivorship", title:"Survivorship", description:"Explore follow-up, recovery, rehabilitation and life after active treatment.", topics:["Life After Cancer Treatment","Why Follow-Up Matters","Fear of Cancer Recurrence","Long-Term Treatment Effects","Returning to Work","Exercise and Rehabilitation After Cancer","Nutrition After Treatment","Emotional Wellbeing in Survivorship"] }
// ];

// const articleTitles = [
//   ["diagnosis","I've Been Diagnosed With Cancer — What Happens Next?","A clear starting point for understanding the next steps after a cancer diagnosis."],
//   ["preparation","15 Questions to Ask Your Oncologist","Use your appointment time well and make space for the questions that matter to you."],
//   ["second-opinion","Should You Get a Second Opinion?","Understand when another specialist review may help and what records to prepare."],
//   ["tumour-board","How Does a Multidisciplinary Tumour Board Work?","Learn how specialists bring different perspectives to complex cancer decisions."],
//   ["exact-diagnosis","Why the Exact Cancer Diagnosis Matters","Cancer type, subtype and tumour biology can influence the care plan."],
//   ["biopsy","What Happens During a Cancer Biopsy?","A patient-friendly overview of tissue sampling and why it may be recommended."],
//   ["pathology-report","How to Read a Cancer Pathology Report","Understand common report sections and what to discuss with your specialist."],
//   ["staging","Cancer Staging Explained","Learn what staging describes and how it helps guide treatment discussions."],
//   ["ct-mri-pet","CT vs MRI vs PET/CT","An overview of different imaging approaches used in cancer care."],
//   ["molecular-testing","What Is Molecular Testing?","Understand how tumour testing can identify features relevant to treatment."],
//   ["liquid-biopsy","What Is a Liquid Biopsy?","Learn how blood-based testing may be used in selected cancer settings."],
//   ["biomarkers","Understanding Cancer Biomarkers","Discover how biomarkers can help characterise a cancer and guide decisions."],
//   ["chemotherapy","Chemotherapy: What to Expect","An overview of how chemotherapy is planned, delivered and monitored."],
//   ["immunotherapy","Immunotherapy Explained Simply","Understand how immunotherapy works and why it is suitable for some cancers."],
//   ["targeted-vs-chemo","Targeted Therapy vs Chemotherapy","Compare two different treatment approaches and the questions to ask."],
//   ["precision-oncology","What Is Precision Oncology?","Learn how clinical and molecular information can inform treatment choices."],
//   ["adc","What Are Antibody-Drug Conjugates?","Explore this targeted approach and why patient selection matters."],
//   ["car-t","CAR T-Cell Therapy Explained","A simple introduction to engineered immune cells and their selected uses."],
//   ["til","TIL Therapy Explained","Understand tumour-infiltrating lymphocyte therapy and its specialised role."],
//   ["bispecific","What Are Bispecific Antibodies?","Learn how these medicines are designed to bring immune cells and targets together."],
//   ["theranostics","What Is Theranostics?","An introduction to linked molecular imaging and targeted radionuclide treatment."],
//   ["sbrt","What Is SBRT?","Understand stereotactic body radiation therapy and its focused delivery."],
//   ["radiosurgery","What Is Stereotactic Radiosurgery?","Learn about highly focused radiation used in selected clinical situations."],
//   ["mr-guided","What Is MR-Guided Radiation?","Explore how MRI guidance can support selected radiation treatments."],
//   ["proton","What Is Proton Therapy?","Understand the physical characteristics of proton radiation and where it may be considered."],
//   ["cyberknife","CyberKnife Explained","Learn why this robotic radiation system is not a form of surgery."],
//   ["gamma-knife","Gamma Knife Explained","An overview of a dedicated radiosurgery platform used for selected brain conditions."],
//   ["robotic-surgery","What Is Robotic Cancer Surgery?","Understand the role and limitations of robotic-assisted surgical approaches."],
//   ["hipec","What Is HIPEC?","Learn about heated chemotherapy delivered into the abdomen during selected procedures."],
//   ["nutrition","Nutrition During Cancer Treatment","Explore practical nutrition conversations to have with your care team."],
//   ["fatigue","Managing Fatigue During Cancer Treatment","Understand cancer-related fatigue and ways your team may help."],
//   ["exercise","Exercise During Cancer Treatment","Learn why activity plans should be adapted to your health and treatment."],
//   ["mental-health","How Cancer Can Affect Mental Health","Recognise emotional wellbeing as an important part of supportive care."],
//   ["caregiver","Supporting Someone With Cancer","Practical ways family and friends can offer useful support."],
//   ["treatment-ends","What Happens When Cancer Treatment Ends?","Understand follow-up, recovery and survivorship planning."],
//   ["recurrence-fear","Fear of Cancer Recurrence","Explore common worries after treatment and when to seek support."],
//   ["return-work","Returning to Work After Cancer Treatment","Consider energy, adjustments and conversations when planning a return to work."],
//   ["late-effects","Long-Term Effects of Cancer Treatment","Learn why follow-up includes attention to ongoing and late effects."]
// ];

// const imagePool = [
//  "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1582719471384-894fbb16e074?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1573497620053-ea5300f94f21?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=1000&q=85",
//  "https://images.unsplash.com/photo-1516574187841-cbca70401754?auto=format&fit=crop&w=1000&q=85"
// ];

// export const healthBlogs = articleTitles.map(([slug,title,description], index) => ({
//   id: slug, slug, title, description,
//   category: index < 12 ? "DIAGNOSIS & TESTS" : index < 29 ? "TREATMENT EDUCATION" : "LIVING & WELLBEING",
//   image: imagePool[index % imagePool.length],
//   readTime: "5 min read",
//   intro: `${title} — understanding the information available can help you have more informed conversations with your cancer care team. The right approach depends on the individual diagnosis, clinical findings and personal circumstances.`,
//   paragraphs: [
//     `${description} Cancer care is individual. Your specialist considers the cancer type, stage, tumour biology, overall health and your preferences before discussing suitable options.`,
//     `The information in this article is intended to explain common terms and questions in clear language. Tests and treatments are not appropriate for everyone, and recommendations may differ between cancer types and between individuals.`,
//     `At your appointment, ask why a particular test or treatment is being considered, what alternatives may be appropriate, what benefits and risks are relevant to you, and how your care will be reviewed. It can help to bring a trusted person and a written list of questions.`,
//     `This educational article does not replace a consultation, diagnosis or treatment advice from a qualified healthcare professional. Please discuss your own circumstances and any new or persistent symptoms with your treating team.`
//   ]
// }));

// export const generalFaqs = [
//  ["Is cancer one disease?","No. Cancer is a broad group of diseases. Different cancers can behave very differently and may need different tests and treatments."],
//  ["Does everyone with cancer need chemotherapy?","No. Treatment depends on the cancer type, stage and individual clinical circumstances. Some cancers are treated mainly with surgery, radiation, hormone therapy, targeted therapy, immunotherapy or other approaches."],
//  ["Is cancer curable?","Some cancers can be cured, especially when diagnosed at a stage where curative treatment is possible. Other cancers may be controlled for long periods. The outlook depends on cancer type, stage, biology, overall health and response to treatment."],
//  ["How is cancer diagnosed?","Diagnosis may involve clinical assessment, imaging, blood tests, endoscopy, biopsy, pathology and molecular testing. A tissue diagnosis is commonly needed for many cancers."],
//  ["What is cancer staging?","Staging describes the extent of cancer and whether it has spread. It helps guide treatment and prognosis discussions."],
//  ["Why is a biopsy important?","A biopsy provides cells or tissue for pathological examination and can also enable biomarker or molecular testing."],
//  ["What is a tumour board?","A tumour board is a multidisciplinary meeting where specialists review complex cases and discuss treatment options."],
//  ["What is precision oncology?","Precision oncology uses biological and molecular information about cancer to help guide treatment when clinically useful."],
//  ["What is targeted therapy?","Targeted therapy acts on particular molecules or pathways involved in cancer growth. The relevant target generally needs to be present."],
//  ["What is immunotherapy?","Immunotherapy helps the immune system recognise or attack cancer. It is useful for some cancers and patients, but not everyone."],
//  ["Is immunotherapy better than chemotherapy?","Not universally. They work differently and may be used separately or together depending on the cancer."],
//  ["What is CAR T-cell therapy?","CAR T-cell therapy modifies a patient’s T cells to recognise a cancer target. Its most established uses are in selected blood cancers."],
//  ["What is TIL therapy?","TIL therapy uses immune cells collected from a tumour, expanded and given back to the patient. Its use is specialised and depends on the cancer and local approvals."],
//  ["What is theranostics?","Theranostics combines targeted molecular imaging with targeted radionuclide treatment using the same or related biological target."],
//  ["What is proton therapy?","Proton therapy is a form of radiation treatment whose physical dose characteristics can reduce radiation beyond the target in selected cases."],
//  ["Is robotic surgery better than open surgery?","Not automatically. The most appropriate surgical approach depends on the tumour, patient anatomy, stage, surgeon expertise and treatment goals."],
//  ["What is CyberKnife?","CyberKnife is a robotic stereotactic radiation system. It does not involve surgical cutting."],
//  ["What is Gamma Knife?","Gamma Knife is a dedicated stereotactic radiosurgery platform used primarily for selected intracranial conditions."],
//  ["Can I get a second opinion after treatment has started?","In many situations, yes. Another specialist can review the diagnosis, treatment delivered, response and possible next steps."],
//  ["Does palliative care mean cancer treatment has stopped?","No. Palliative care focuses on symptoms and quality of life and can be provided alongside active cancer treatment."],
//  ["Can cancer treatment affect fertility?","Yes. Some surgery, chemotherapy, radiation and other treatments can affect fertility. Patients concerned about future fertility should discuss preservation options before treatment when possible."],
//  ["What happens after cancer treatment?","Follow-up depends on the cancer and treatment. It can include clinical review, imaging, laboratory testing, rehabilitation and management of treatment-related effects."]
// ].map(([question,answer], i) => ({id:`faq-${i+1}`,question,answer}));

// export const healthVideos = existingVideos.map((video, index) => ({
//   ...video,
//   title: video.title || `Cancer education video ${index+1}`,
//   youtubeId: video.youtubeId || "Kye2oX-b39E"
// }));
