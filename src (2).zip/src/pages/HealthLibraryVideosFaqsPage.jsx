import { useState } from "react";
import { PlayCircle, ChevronDown } from "lucide-react";
import { PageLayout } from "../components/PageChrome";
import { healthVideos, generalFaqs } from "../data/healthLibraryContent";

export default function HealthLibraryVideosFaqsPage() {
  const [tab,setTab]=useState("videos");
  const [visible,setVisible]=useState(16);
  const [openFaq,setOpenFaq]=useState(0);
  return <PageLayout eyebrow="HEALTH LIBRARY" title="Videos & Frequently Asked Questions" description="Watch educational videos and find clear answers to common cancer care questions." breadcrumbItems={[{label:"Home",path:"/"},{label:"Health Library",path:"/health-library"},{label:"Videos & FAQs"}]}>
    <div className="mb-8 flex gap-2 border-b border-line">
      <button onClick={()=>setTab("videos")} className={`inline-flex items-center gap-2 border-b-2 px-5 py-3 text-sm font-bold ${tab==="videos"?"border-royal text-royal":"border-transparent text-ink/70"}`}><PlayCircle size={17}/> Videos</button>
      <button onClick={()=>setTab("faqs")} className={`border-b-2 px-5 py-3 text-sm font-bold ${tab==="faqs"?"border-royal text-royal":"border-transparent text-ink/70"}`}>FAQs</button>
    </div>
    {tab==="videos" ? <>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {healthVideos.slice(0,visible).map(video=><article key={video.id} className="overflow-hidden rounded-2xl border border-line bg-white shadow-sm"><div className="aspect-video bg-black"><iframe className="h-full w-full" src={`https://www.youtube-nocookie.com/embed/${video.youtubeId}`} title={video.title} loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen/></div><div className="p-4"><h2 className="font-bold leading-snug text-heading">{video.title}</h2><a href={video.url} target="_blank" rel="noreferrer" className="mt-3 inline-block text-sm font-bold text-royal hover:underline">Watch on YouTube ↗</a></div></article>)}
      </div>
      {visible<healthVideos.length && <div className="mt-10 text-center"><button onClick={()=>setVisible(v=>Math.min(v+8,healthVideos.length))} className="btn-primary">Load more videos</button></div>}
      {healthVideos.length===0 && <p className="rounded-xl bg-mist p-6 text-sm">Videos will appear here when the RENOVA YouTube video list is added.</p>}
      <p className="mt-6 text-xs text-ink/60">Videos are embedded from YouTube. Only videos included in the Health Library video data are displayed; this page does not automatically import every video from a YouTube channel.</p>
    </> : <section className="mx-auto max-w-4xl">
      <div className="mb-5"><h2 className="display-font text-2xl font-bold">General Cancer FAQs</h2><p className="mt-2 text-sm">Select a question to view its answer. Opening another question closes the previous one.</p></div>
      <div className="space-y-3">{generalFaqs.map((faq,index)=><article key={faq.id} className="overflow-hidden rounded-xl border border-line bg-white"><button onClick={()=>setOpenFaq(current=>current===index?-1:index)} aria-expanded={openFaq===index} className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"><span className="font-bold text-heading">{faq.question}</span><ChevronDown size={19} className={`shrink-0 text-royal transition-transform ${openFaq===index?"rotate-180":""}`}/></button>{openFaq===index && <div className="border-t border-line bg-mist/70 px-5 py-4 text-sm leading-7">{faq.answer}</div>}</article>)}</div>
    </section>}
  </PageLayout>;
}
