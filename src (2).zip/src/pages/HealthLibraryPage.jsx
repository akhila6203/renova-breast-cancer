
import { Link, useSearchParams } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { healthCategories } from "../data/healthLibraryData";
import HealthLibraryTabs from "../components/health-library/HealthLibraryTabs";

export default function HealthLibraryPage() {
  const [searchParams] = useSearchParams();
  const requestedTab = searchParams.get("tab");

  const initialTab = ["blogs", "videos", "faqs"].includes(requestedTab)
    ? requestedTab
    : "blogs";

  return (
    <main className="min-h-screen bg-white">
      {/* HERO */}
      <section className="bg-gradient-to-r from-[#eff6f9] via-[#f8fbfc] to-[#edf6f5]">
        <div className="mx-auto max-w-7xl px-4 pb-16 pt-6 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <Link to="/" className="hover:text-teal-700">Home</Link>
            <span>/</span>
            <span className="font-medium text-[#23658a]">Health Library</span>
          </div>

          <div className="mx-auto mt-14 max-w-3xl text-center">
            <span className="text-xs font-bold uppercase tracking-[2px] text-teal-700">
              RENOVA CANCER CENTRE
            </span>
            <h1 className="mt-4 text-4xl font-extrabold text-[#173b56] sm:text-5xl lg:text-6xl">
              Health Library
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-slate-600 sm:text-lg">
              Knowledge brings confidence. Explore trusted information about
              cancer, diagnosis, treatments, prevention and life beyond treatment.
            </p>
          </div>
        </div>
      </section>

      {/* CATEGORY SECTIONS */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <span className="text-xs font-bold uppercase tracking-[2px] text-teal-700">
              Explore & Understand
            </span>
            <h2 className="mt-3 text-3xl font-bold text-[#173b56] sm:text-4xl">
              Your Guide to Cancer Care
            </h2>
            <p className="mt-4 text-base leading-7 text-slate-500">
              Find clear and helpful information at every stage of your cancer care journey.
            </p>
          </div>

          <div className="space-y-14">
            {healthCategories.map((category, index) => {
              const reversed = index % 2 === 1;

              return (
                <article
                  key={category.slug}
                  className="grid items-center gap-8 border-b border-slate-200 pb-14 last:border-0 lg:grid-cols-2 lg:gap-14"
                >
                  <div className={reversed ? "lg:order-2" : ""}>
                    <div className="relative overflow-hidden rounded-xl bg-slate-100">
                      <img
                        src={category.image}
                        alt={category.title}
                        loading="lazy"
                        className="h-[260px] w-full object-cover transition duration-500 hover:scale-105 sm:h-[340px]"
                      />
                      <span className="absolute bottom-4 left-4 flex h-12 w-12 items-center justify-center rounded-md bg-white text-base font-extrabold text-[#173b56] shadow">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                    </div>
                  </div>

                  <div className={reversed ? "lg:order-1" : ""}>
                    <span className="text-xs font-bold uppercase tracking-[1.5px] text-teal-700">
                      HEALTH LIBRARY / {String(index + 1).padStart(2, "0")}
                    </span>

                    <h3 className="mt-3 text-3xl font-bold text-[#173b56]">
                      {category.title}
                    </h3>

                    <h4 className="mt-3 text-lg font-semibold leading-7 text-[#23658a]">
                      {category.subtitle}
                    </h4>

                    <p className="mt-4 text-base leading-8 text-slate-600">
                      {category.description}
                    </p>

                    <div className="mt-5 flex flex-wrap gap-2">
                      {category.topics.slice(0, 4).map(topic => (
                        <span
                          key={topic}
                          className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-600"
                        >
                          {topic}
                        </span>
                      ))}
                      {category.topics.length > 4 && (
                        <span className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-teal-700">
                          +{category.topics.length - 4} more
                        </span>
                      )}
                    </div>

                    <div className="mt-7">
                      <Link
                        to={category.externalPath || `/health-library/${category.slug}`}
                        className="inline-flex items-center gap-3 rounded bg-[#23658a] px-6 py-3.5 text-sm font-bold text-white transition hover:bg-teal-700"
                      >
                        {category.externalLabel || "Know More"}
                        <ArrowRight size={17} />
                      </Link>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* BLOGS / VIDEOS / FAQS */}
      <div id="health-library-resources">
        <HealthLibraryTabs initialTab={initialTab} />
      </div>

      {/* DISCLAIMER */}
      <section className="border-t border-slate-200 bg-white py-7">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-sm leading-7 text-slate-500">
            <strong className="text-[#173b56]">Medical information disclaimer:</strong>{" "}
            The information in this Health Library is for general educational
            purposes only. It does not replace medical advice, diagnosis or
            treatment. Please consult your treating doctor for individual advice.
          </p>
        </div>
      </section>
    </main>
  );
}


















// import { useMemo, useState } from "react";
// import { Link } from "react-router-dom";
// import { ArrowRight, BookOpen, CircleHelp, PlayCircle } from "lucide-react";
// import { PageLayout } from "../components/PageChrome";
// import BlogCard from "../components/health-library/BlogCard";
// import { libraryCategories, healthBlogs, generalFaqs } from "../data/healthLibraryContent";

// export default function HealthLibraryPage() {
//   const [tab, setTab] = useState("blogs");
//   const featured = useMemo(() => healthBlogs.slice(0, 4), []);
//   return (
//     <PageLayout eyebrow="RENOVA HEALTH LIBRARY" title="Understand Cancer. Understand Your Options." description="A medically reviewed education hub for patients, families and caregivers." breadcrumbItems={[{label:"Home",path:"/"},{label:"Health Library"}]}>
//       <section className="mb-12 rounded-3xl bg-mist p-6 sm:p-9">
//         <div className="max-w-3xl">
//           <p className="text-sm font-bold tracking-widest text-royal">LEARN AT YOUR OWN PACE</p>
//           <h2 className="display-font mt-2 text-2xl font-bold sm:text-3xl">Clear information for every step of your care journey</h2>
//           <p className="mt-3 text-base leading-7">Explore cancer basics, symptoms, diagnosis, treatment education, prevention, supportive care and survivorship. These resources help you prepare for informed conversations with your healthcare team.</p>
//         </div>
//       </section>

//       <div className="mb-7 flex flex-wrap items-end justify-between gap-3">
//         <div><p className="text-sm font-bold tracking-widest text-royal">EXPLORE TOPICS</p><h2 className="display-font mt-1 text-2xl font-bold">Health Library categories</h2></div>
//       </div>
//       <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
//         {libraryCategories.map((category, i) => (
//           <Link key={category.slug} to={`/health-library/${category.slug}`} className="group rounded-2xl border border-line bg-white p-5 transition hover:-translate-y-1 hover:border-royal hover:shadow-md">
//             <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ice text-royal"><BookOpen size={21}/></span>
//             <h3 className="display-font mt-4 text-lg font-bold group-hover:text-royal">{category.title}</h3>
//             <p className="mt-2 text-sm leading-6">{category.description}</p>
//             <span className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-royal">{category.topics.length} topics <ArrowRight size={15}/></span>
//           </Link>
//         ))}
//       </div>

//       <section className="mt-16">
//         <div className="flex flex-wrap items-end justify-between gap-4">
//           <div><p className="text-sm font-bold tracking-widest text-royal">PATIENT RESOURCES</p><h2 className="display-font mt-1 text-2xl font-bold sm:text-3xl">Blogs & FAQs</h2><p className="mt-2 max-w-2xl text-sm">Explore practical articles and answers to common questions.</p></div>
//           <Link to="/health-library/blogs" className="text-sm font-bold text-royal hover:underline">View all articles <ArrowRight className="ml-1 inline" size={15}/></Link>
//         </div>
//         <div className="mt-6 flex gap-2 border-b border-line">
//           <button onClick={()=>setTab("blogs")} className={`border-b-2 px-5 py-3 text-sm font-bold ${tab==="blogs"?"border-royal text-royal":"border-transparent text-ink/70"}`}>Blogs</button>
//           <button onClick={()=>setTab("faqs")} className={`border-b-2 px-5 py-3 text-sm font-bold ${tab==="faqs"?"border-royal text-royal":"border-transparent text-ink/70"}`}>FAQs</button>
//         </div>
//         {tab==="blogs" ? <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{featured.map(blog=><BlogCard key={blog.id} blog={blog}/>)}</div> :
//           <div className="mt-6 grid gap-3 md:grid-cols-2">{generalFaqs.slice(0,4).map(f=><div key={f.id} className="rounded-xl border border-line p-4"><h3 className="font-bold text-heading">{f.question}</h3><p className="mt-2 text-sm leading-6">{f.answer}</p></div>)}</div>}
//         <div className="mt-6 flex flex-wrap gap-3">
//           <Link to="/health-library/blogs" className="btn-primary">All Blogs <ArrowRight size={16}/></Link>
//           <Link to="/health-library/videos-faqs" className="btn-secondary"><PlayCircle size={16}/> Videos & FAQs</Link>
//         </div>
//       </section>
//       <p className="mt-12 rounded-xl border border-line bg-white p-4 text-xs leading-5 text-ink/70">Medical information notice: Health Library content is educational and does not replace an individual consultation, diagnosis or treatment advice. Content should be reviewed and approved by RENOVA’s clinical team before publication.</p>
//     </PageLayout>
//   );
// }
