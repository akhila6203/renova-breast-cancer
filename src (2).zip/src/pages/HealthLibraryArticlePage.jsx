
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Clock3 } from "lucide-react";
import { healthBlogs } from "../data/healthLibraryData";

export default function HealthLibraryArticlePage() {
  const { slug } = useParams();
  const blog = healthBlogs.find(item => item.slug === slug);

  if (!blog) {
    return (
      <div className="mx-auto max-w-7xl px-5 py-24 text-center">
        <h1 className="text-3xl font-bold text-[#173b56]">
          Article Not Found
        </h1>
        <Link
          to="/health-library/blogs"
          className="mt-5 inline-block font-semibold text-teal-700"
        >
          View All Blogs
        </Link>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-white">
      <section className="bg-[#f1f7fa] py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <Link to="/">Home</Link>
            <span>/</span>
            <Link to="/health-library">Health Library</Link>
            <span>/</span>
            <Link to="/health-library/blogs">Blogs</Link>
            <span>/</span>
            <span className="text-[#23658a]">Article</span>
          </div>

          <div className="mx-auto mt-12 max-w-4xl text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-700">
              {blog.category}
            </span>
            <h1 className="mt-4 text-3xl font-extrabold leading-tight text-[#173b56] sm:text-5xl">
              {blog.title}
            </h1>
            <p className="mt-5 text-base leading-8 text-slate-600">
              {blog.excerpt}
            </p>
            <span className="mt-5 inline-flex items-center gap-2 text-sm text-slate-500">
              <Clock3 size={16} /> {blog.readTime}
            </span>
          </div>
        </div>
      </section>

      <article className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Link
          to="/health-library/blogs"
          className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-[#23658a] hover:text-teal-700"
        >
          <ArrowLeft size={17} /> Back to All Blogs
        </Link>

        <img
          src={blog.image}
          alt={blog.title}
          className="mb-10 h-64 w-full rounded-xl object-cover sm:h-[430px]"
        />

        <div className="space-y-6">
          {blog.content.map((paragraph, index) => (
            <p key={index} className="text-base leading-8 text-slate-700">
              {paragraph}
            </p>
          ))}
        </div>

        <div className="mt-10 rounded-md border-l-4 border-teal-600 bg-slate-50 p-6">
          <p className="text-sm leading-7 text-slate-600">
            <strong className="text-[#173b56]">Important:</strong> This article
            is for general educational purposes only. Please consult your
            oncologist or qualified healthcare professional for advice about
            your individual condition.
          </p>
        </div>
      </article>
    </main>
  );
}





// import { Link, useParams } from "react-router-dom";
// import { ArrowLeft, Clock3 } from "lucide-react";
// import { PageLayout } from "../components/PageChrome";
// import { healthBlogs } from "../data/healthLibraryContent";

// export default function HealthLibraryArticlePage() {
//   const { slug } = useParams();
//   const blog = healthBlogs.find(item=>item.slug===slug);
//   if (!blog) return <PageLayout eyebrow="HEALTH LIBRARY" title="Article not found" description="The requested article could not be found."><Link to="/health-library/blogs" className="text-royal">Browse all articles</Link></PageLayout>;
//   return <PageLayout eyebrow="HEALTH LIBRARY / ARTICLE" title={blog.title} description={blog.description} breadcrumbItems={[{label:"Home",path:"/"},{label:"Health Library",path:"/health-library"},{label:"Blogs",path:"/health-library/blogs"},{label:"Article"}]}>
//     <article className="mx-auto max-w-4xl">
//       <Link to="/health-library/blogs" className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-royal"><ArrowLeft size={16}/> All articles</Link>
//       <img src={blog.image} alt="" className="mb-7 max-h-[460px] w-full rounded-3xl object-cover"/>
//       <div className="flex flex-wrap items-center gap-4 text-xs font-bold tracking-widest text-royal"><span>{blog.category}</span><span className="inline-flex items-center gap-1 text-ink/60 normal-case tracking-normal"><Clock3 size={14}/>{blog.readTime}</span></div>
//       <h1 className="display-font mt-3 text-3xl font-bold sm:text-4xl">{blog.title}</h1>
//       <p className="mt-5 text-lg leading-8 text-ink">{blog.intro}</p>
//       <div className="mt-7 space-y-5">{blog.paragraphs.map((paragraph,i)=><p key={i} className="text-base leading-8 text-ink">{paragraph}</p>)}</div>
//       <div className="mt-9 rounded-2xl bg-mist p-6"><h2 className="display-font text-xl font-bold">Questions to discuss with your care team</h2><ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-6"><li>How does this information apply to my diagnosis?</li><li>Are there other tests or options I should understand?</li><li>What should I expect next, and who can I contact with concerns?</li></ul></div>
//       <p className="mt-7 border-l-4 border-sky pl-4 text-sm leading-6 text-ink/70">This article is for general education only. It does not replace advice from your oncologist or other qualified healthcare professional. Individual recommendations depend on your clinical circumstances.</p>
//     </article>
//   </PageLayout>;
// }
