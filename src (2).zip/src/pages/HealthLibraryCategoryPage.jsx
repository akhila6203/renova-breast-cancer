
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { healthCategories, healthBlogs } from "../data/healthLibraryData";
import BlogCard from "../components/health-library/BlogCard";

export default function HealthLibraryCategoryPage() {
  const { slug } = useParams();

  const category = healthCategories.find(item => item.slug === slug);

  if (!category) {
    return (
      <div className="mx-auto max-w-7xl px-5 py-24 text-center">
        <h1 className="text-3xl font-bold text-[#173b56]">Category Not Found</h1>
        <Link to="/health-library" className="mt-5 inline-flex text-teal-700">
          Back to Health Library
        </Link>
      </div>
    );
  }

  if (category.externalPath) {
    return (
      <div className="mx-auto max-w-7xl px-5 py-24 text-center">
        <h1 className="text-3xl font-bold text-[#173b56]">{category.title}</h1>
        <p className="mx-auto mt-4 max-w-2xl leading-7 text-slate-600">
          {category.description}
        </p>
        <Link
          to={category.externalPath}
          className="mt-7 inline-flex items-center gap-2 rounded bg-[#23658a] px-6 py-3 font-bold text-white hover:bg-teal-700"
        >
          {category.externalLabel} <ArrowRight size={17} />
        </Link>
      </div>
    );
  }

  const relatedBlogs = healthBlogs.filter(
    blog => blog.categorySlug === category.slug
  );

  return (
    <main className="min-h-screen bg-white">
      <section className="bg-[#f1f7fa] py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <Link to="/" className="hover:text-teal-700">Home</Link>
            <span>/</span>
            <Link to="/health-library" className="hover:text-teal-700">Health Library</Link>
            <span>/</span>
            <span className="text-[#23658a]">{category.title}</span>
          </div>

          <div className="mx-auto mt-12 max-w-3xl text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-700">
              RENOVA HEALTH LIBRARY
            </span>
            <h1 className="mt-3 text-4xl font-bold text-[#173b56] sm:text-5xl">
              {category.title}
            </h1>
            <p className="mt-4 text-base leading-7 text-slate-600">
              {category.subtitle}
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <Link
          to="/health-library"
          className="mb-9 inline-flex items-center gap-2 text-sm font-bold text-[#23658a] hover:text-teal-700"
        >
          <ArrowLeft size={17} /> Back to Health Library
        </Link>

        <div className="grid items-center gap-9 lg:grid-cols-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-teal-700">
              UNDERSTANDING YOUR HEALTH
            </span>
            <h2 className="mt-3 text-3xl font-bold text-[#173b56]">
              {category.title}: A Patient Guide
            </h2>
            <p className="mt-5 text-base leading-8 text-slate-600">
              {category.description}
            </p>
          </div>

          <img
            src={category.image}
            alt={category.title}
            className="h-72 w-full rounded-xl object-cover sm:h-96"
          />
        </div>

        <div className="mt-16">
          <span className="text-xs font-bold uppercase tracking-widest text-teal-700">
            Explore the Topics
          </span>
          <h2 className="mb-7 mt-3 text-3xl font-bold text-[#173b56]">
            Topics Covered
          </h2>

          <div className="grid gap-3 sm:grid-cols-2">
            {category.topics.map((topic, index) => (
              <div
                key={topic}
                className="flex items-center gap-4 rounded-md border border-slate-200 bg-slate-50 p-4"
              >
                <span className="font-bold text-teal-700">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="text-sm font-semibold text-[#173b56]">
                  {topic}
                </span>
              </div>
            ))}
          </div>
        </div>

        {relatedBlogs.length > 0 && (
          <div className="mt-16">
            <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-teal-700">
                  Read More
                </span>
                <h2 className="mt-2 text-3xl font-bold text-[#173b56]">
                  Related Articles
                </h2>
              </div>
              <Link
                to="/health-library/blogs"
                className="inline-flex items-center gap-2 text-sm font-bold text-[#23658a] hover:text-teal-700"
              >
                All Blogs <ArrowRight size={16} />
              </Link>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {relatedBlogs.slice(0, 4).map(blog => (
                <BlogCard key={blog.slug} blog={blog} />
              ))}
            </div>
          </div>
        )}
      </section>
    </main>
  );
}






















// import { Link, useParams } from "react-router-dom";
// import { ArrowLeft, ArrowRight } from "lucide-react";
// import { PageLayout } from "../components/PageChrome";
// import { libraryCategories } from "../data/healthLibraryContent";

// export default function HealthLibraryCategoryPage() {
//   const { slug } = useParams();
//   const category = libraryCategories.find(item=>item.slug===slug);
//   if (!category) return <PageLayout eyebrow="HEALTH LIBRARY" title="Topic not found" description="Please return to the Health Library."><Link to="/health-library" className="text-royal">Back to Health Library</Link></PageLayout>;
//   return <PageLayout eyebrow="HEALTH LIBRARY" title={category.title} description={category.description} breadcrumbItems={[{label:"Home",path:"/"},{label:"Health Library",path:"/health-library"},{label:category.title}]}>
//     <Link to="/health-library" className="mb-7 inline-flex items-center gap-2 text-sm font-bold text-royal"><ArrowLeft size={16}/> Back to Health Library</Link>
//     <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{category.topics.map((topic,i)=><article key={topic} className="rounded-2xl border border-line bg-white p-5"><p className="text-xs font-bold tracking-widest text-royal">TOPIC {String(i+1).padStart(2,"0")}</p><h2 className="display-font mt-2 text-lg font-bold">{topic}</h2><p className="mt-2 text-sm leading-6">Explore this topic with your care team and learn the key terms, questions and considerations that may be relevant to your situation.</p><Link to="/health-library/blogs" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-royal">Explore related articles <ArrowRight size={15}/></Link></article>)}</div>
//   </PageLayout>;
// }
