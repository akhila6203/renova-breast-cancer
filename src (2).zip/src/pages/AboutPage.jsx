

import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  HeartHandshake,
  ShieldCheck,
  Stethoscope,
  Users,
  Target,
  Eye,
  Handshake,
  Lightbulb,
  Award,
  CheckCircle2,
  Microscope,
  Building2,
  ClipboardCheck,
  Heart,
  Sparkles,
  MapPin,
  Phone,
} from "lucide-react";

import SectionTitle from "../components/SectionTitle";

import breastBanner from "../assets/home/breast-banner.png";
import assessmentImage from "../assets/home/assessment.jpg";
import patientCareImage from "../assets/home/patientCare.jpg";
import diagnosticImagingImage from "../assets/home/diagnostic-imaging.jpg";
import treatmentImage from "../assets/home/treatmentBanner3.jpg";

// --------------------------------------------------
// REUSABLE ANIMATION
// --------------------------------------------------

function Reveal({
  children,
  className = "",
  direction = "up",
  delay = 0,
}) {
  const reduceMotion = useReducedMotion();

  const initialPosition = {
    left: { x: -45, y: 0 },
    right: { x: 45, y: 0 },
    up: { x: 0, y: 28 },
  };

  return (
    <motion.div
      initial={{
        opacity: 0,
        ...(reduceMotion ? { x: 0, y: 0 } : initialPosition[direction]),
      }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{
        duration: reduceMotion ? 0 : 0.65,
        delay: reduceMotion ? 0 : delay,
        ease: [0.22, 1, 0.36, 1],
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

// --------------------------------------------------
// PAGE NAVIGATION
// --------------------------------------------------

const aboutLinks = [
  { label: "About RENOVA", id: "about-renova" },
  { label: "Our Approach", id: "our-approach" },
  { label: "Mission & Vision", id: "mission-vision" },
  { label: "Core Values", id: "core-values" },
  { label: "Inclusion", id: "inclusion" },
  { label: "One RENOVA", id: "one-renova" },
  { label: "Quality & Safety", id: "quality-safety" },
  { label: "Technology", id: "technology" },
  { label: "Locations", id: "locations" },
];

// --------------------------------------------------
// APPROACH DATA
// --------------------------------------------------

const approachItems = [
  {
    icon: Target,
    title: "Personalised Treatment Planning",
    description:
      "Developing care plans based on each patient's diagnosis, clinical needs and treatment goals.",
  },
  {
    icon: Users,
    title: "Multidisciplinary Expertise",
    description:
      "Encouraging collaboration between relevant specialists to support well-informed treatment decisions.",
  },
  {
    icon: Microscope,
    title: "Evidence-Based Treatment Options",
    description:
      "Considering appropriate cancer treatments based on individual clinical requirements and established medical evidence.",
  },
  {
    icon: HeartHandshake,
    title: "Patient & Family Support",
    description:
      "Providing clear information, guidance and compassionate support to patients and their families.",
  },
  {
    icon: ClipboardCheck,
    title: "Continuity of Care",
    description:
      "Supporting patients from initial assessment and diagnosis through treatment and follow-up care.",
  },
];

const values = [
  {
    icon: HeartHandshake,
    title: "Compassion",
    description:
      "Understanding individual concerns and treating every patient with kindness and empathy.",
  },
  {
    icon: Users,
    title: "Respect",
    description:
      "Recognising the dignity, choices and individual needs of every patient and family.",
  },
  {
    icon: Award,
    title: "Clinical Excellence",
    description:
      "Valuing clinical expertise and thoughtful decisions in cancer care.",
  },
  {
    icon: ShieldCheck,
    title: "Integrity",
    description:
      "Promoting honest communication, transparency and responsible care.",
  },
  {
    icon: Handshake,
    title: "Collaboration",
    description:
      "Bringing relevant healthcare professionals together to support coordinated care.",
  },
  {
    icon: Heart,
    title: "Patient-Centred Care",
    description:
      "Keeping the patient's wellbeing, preferences and needs at the heart of every decision.",
  },
  {
    icon: Lightbulb,
    title: "Innovation",
    description:
      "Remaining open to meaningful improvements in healthcare practices and technology.",
  },
  {
    icon: Sparkles,
    title: "Inclusion",
    description:
      "Valuing individual differences and creating a respectful, supportive care environment.",
  },
];

// --------------------------------------------------
// MAIN PAGE
// --------------------------------------------------

export default function AboutPage() {
  const reduceMotion = useReducedMotion();

  return (
    <main className="min-h-screen overflow-hidden bg-[#fffdf9] text-[#304b3c]">

      {/* BREADCRUMB */}
      <nav
        aria-label="Breadcrumb"
        className="border-b border-[#e5e9e3] bg-[#f7f9f6]"
      >
        <div className="page-container px-5 py-3 sm:px-8 lg:px-12">
          <ol className="flex items-center gap-2 text-sm sm:text-base">
            <li>
              <Link
                to="/"
                className="font-semibold text-[#304b3c] transition-colors hover:text-[#f26322]"
              >
                Home
              </Link>
            </li>
            <li className="text-[#aab5aa]">/</li>
            <li className="font-semibold text-[#304b3c]">
              About Us
            </li>
          </ol>
        </div>
      </nav>

      {/* PAGE HERO */}
      <section
        id="about-renova"
        className="relative overflow-hidden bg-gradient-to-br from-[#243c30] via-[#304b3c] to-[#496c54]"
      >
        <div className="absolute -right-28 -top-32 h-80 w-80 rounded-full border-[35px] border-white/[0.06]" />
        <div className="absolute -bottom-36 left-[35%] h-80 w-80 rounded-full bg-[#f26322]/10 blur-3xl" />

        <div className="page-container relative grid items-center gap-10 px-5 py-14 sm:px-8 sm:py-20 lg:grid-cols-[1.05fr_0.95fr] lg:gap-14 lg:px-12 lg:py-24">

          <Reveal direction="left">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-xs font-bold tracking-[0.16em] text-[#ffd0b6] sm:text-sm">
              <HeartHandshake size={16} />
              ABOUT RENOVA
            </span>

            <h1 className="display-font mt-6 max-w-2xl text-3xl font-bold leading-tight text-white sm:text-4xl lg:text-6xl">
              Dedicated Cancer Care,
              <span className="mt-2 block text-[#ffb38d]">
                Guided by Compassion
              </span>
            </h1>

            <p className="mt-6 max-w-2xl text-base leading-8 text-white/85 sm:text-lg">
              At RENOVA Cancer Hospital, we are committed to providing
              dedicated cancer care with compassion, clinical expertise
              and a patient-centred approach. We recognise that every
              cancer journey is unique, and every patient deserves to
              be treated with dignity, understanding and respect.
            </p>

            <p className="mt-4 max-w-2xl text-base leading-8 text-white/80 sm:text-lg">
              Our approach brings together specialist assessment,
              personalised treatment planning and coordinated care
              to help patients and their families make informed
              decisions throughout their cancer journey.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#our-approach"
                className="inline-flex min-h-12 items-center gap-2 rounded-full bg-[#f26322] px-7 py-3 text-sm font-bold text-white shadow-lg transition duration-300 hover:-translate-y-1 hover:bg-[#df551a] hover:shadow-xl sm:text-base"
              >
                Explore Our Approach
                <ArrowRight size={18} />
              </a>

              <Link
                to="/contact"
                className="inline-flex min-h-12 items-center gap-2 rounded-full border border-white/50 bg-white/10 px-7 py-3 text-sm font-bold text-white transition duration-300 hover:-translate-y-1 hover:bg-white hover:text-[#304b3c] sm:text-base"
              >
                Contact Us
                <ArrowUpRight size={17} />
              </Link>
            </div>
          </Reveal>

          <Reveal direction="right" delay={0.12}>
            <div className="relative mx-auto w-full max-w-xl">

              <div className="absolute -right-3 -top-3 h-28 w-28 rounded-tr-[3rem] border-r-4 border-t-4 border-[#f26322] sm:-right-5 sm:-top-5 sm:h-36 sm:w-36" />

              <div className="relative overflow-hidden rounded-[2rem_2rem_2rem_5rem] border-[7px] border-white/15 shadow-2xl">
                <img
                  src={breastBanner}
                  alt="RENOVA breast care"
                  className="h-[280px] w-full object-cover sm:h-[380px] lg:h-[470px]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#243c30]/40 to-transparent" />
              </div>

              <div className="absolute -bottom-6 -left-2 flex max-w-[270px] items-center gap-3 rounded-2xl border border-[#e3e9df] bg-white p-4 shadow-xl sm:-left-7 sm:p-5">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#e7eee7] text-[#304b3c]">
                  <HeartHandshake size={26} />
                </span>
                <div>
                  <p className="font-bold text-[#304b3c]">
                    Compassionate Care
                  </p>
                  <p className="mt-1 text-sm text-[#647368]">
                    Every patient matters.
                  </p>
                </div>
              </div>

              <div className="absolute -bottom-8 right-5 -z-10 h-32 w-32 rounded-full bg-[#f26322]/20 blur-2xl" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* SECTION NAVIGATION */}
      <section className="sticky top-[72px] z-30 border-b border-[#e1e8df] bg-white/95 py-3 shadow-sm backdrop-blur-md">
        <div className="page-container px-5 sm:px-8 lg:px-12">
          <div className="hide-scroll flex gap-2 overflow-x-auto pb-1">
            {aboutLinks.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className="shrink-0 rounded-full border border-[#dce6dc] bg-[#f7f9f6] px-4 py-2 text-xs font-semibold text-[#304b3c] transition duration-300 hover:border-[#f26322] hover:bg-[#304b3c] hover:text-white sm:text-sm"
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* OUR APPROACH */}
      <section
        id="our-approach"
        className="scroll-mt-32 px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container">

          <div className="grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">

            <Reveal direction="left">
              <div className="relative">
                <div className="absolute -left-3 -top-3 h-24 w-24 rounded-tl-[2.5rem] border-l-4 border-t-4 border-[#f26322] sm:-left-5 sm:-top-5 sm:h-32 sm:w-32" />

                <img
                  src={assessmentImage}
                  alt="Cancer care assessment"
                  loading="lazy"
                  className="relative h-[300px] w-full rounded-[2rem_1rem_2rem_1rem] object-cover shadow-xl sm:h-[430px]"
                />

                <div className="absolute -bottom-5 right-4 rounded-2xl bg-[#304b3c] px-5 py-4 text-white shadow-xl sm:right-[-18px]">
                  <p className="text-sm font-semibold text-white/75">
                    OUR COMMITMENT
                  </p>
                  <p className="mt-1 text-xl font-bold text-white">
                    Care with Compassion
                  </p>
                </div>
              </div>
            </Reveal>

            <Reveal direction="right">
              <span className="text-sm font-bold tracking-[0.17em] text-[#f26322]">
                OUR APPROACH TO CANCER CARE
              </span>

              <h2 className="display-font mt-3 text-3xl font-bold leading-tight text-[#304b3c] sm:text-4xl lg:text-5xl">
                Care That Goes Beyond Treatment
              </h2>

              <p className="mt-5 text-base leading-8 text-[#526357] sm:text-lg">
                Cancer care involves more than a treatment plan.
                It requires a thorough understanding of each patient's
                condition, careful consideration of appropriate
                treatment options and ongoing support throughout
                the care journey.
              </p>

              <p className="mt-4 text-base leading-8 text-[#526357] sm:text-lg">
                Our approach focuses on individual needs, clear
                communication and coordinated care so patients
                and families can take part in informed discussions
                about their care.
              </p>

              <div className="mt-7 flex items-center gap-3 border-l-4 border-[#f26322] bg-[#f7f9f6] p-4 sm:p-5">
                <HeartHandshake className="shrink-0 text-[#304b3c]" size={28} />
                <p className="text-sm font-semibold leading-7 text-[#304b3c] sm:text-base">
                  Every patient's journey is unique. Their care should
                  recognise that.
                </p>
              </div>
            </Reveal>
          </div>

          {/* APPROACH CARDS */}
          <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {approachItems.map(({ icon: Icon, title, description }, index) => (
              <Reveal key={title} delay={index * 0.07}>
                <motion.article
                  whileHover={reduceMotion ? {} : { y: -7 }}
                  className="group h-full rounded-3xl border border-[#dfe8de] bg-white p-6 shadow-[0_5px_20px_rgba(48,75,60,0.05)] transition-all duration-300 hover:border-[#f26322]/60 hover:shadow-[0_15px_35px_rgba(48,75,60,0.12)] sm:p-7"
                >
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#e7eee7] text-[#304b3c] transition-all duration-300 group-hover:rotate-[-5deg] group-hover:bg-[#304b3c] group-hover:text-white">
                    <Icon size={27} />
                  </span>

                  <h3 className="display-font mt-5 text-xl font-bold leading-snug text-[#304b3c]">
                    {title}
                  </h3>

                  <p className="mt-3 text-base leading-7 text-[#647368]">
                    {description}
                  </p>

                  <div className="mt-5 h-1 w-10 rounded-full bg-[#f26322] transition-all duration-300 group-hover:w-20" />
                </motion.article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section
        id="mission-vision"
        className="scroll-mt-32 bg-[#f1f5f0] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container">

          <SectionTitle
            eyebrow="OUR PURPOSE"
            title="Our Mission & Vision"
            description="Our mission and vision guide our commitment to clinical excellence, innovation and compassionate cancer care."
          />

          <div className="mt-10 grid gap-7 lg:grid-cols-2">

            <Reveal direction="left">
              <motion.article
                whileHover={reduceMotion ? {} : { y: -6 }}
                className="relative h-full overflow-hidden rounded-[2rem] bg-[#304b3c] p-7 text-white shadow-xl sm:p-10"
              >
                <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full border-[22px] border-white/[0.07]" />

                <span className="relative grid h-16 w-16 place-items-center rounded-2xl bg-white/15 text-[#ffb38d]">
                  <Target size={32} />
                </span>

                <p className="relative mt-7 text-sm font-bold tracking-[0.18em] text-[#ffb38d]">
                  OUR MISSION
                </p>

                <h3 className="display-font relative mt-3 text-2xl font-bold text-white sm:text-3xl">
                  Advancing Care Through Expertise
                </h3>

                <p className="relative mt-5 text-base leading-8 text-white/85 sm:text-lg">
                  To advance cancer care through clinical expertise,
                  evidence-based treatment and compassionate support
                  for every patient.
                </p>
              </motion.article>
            </Reveal>

            <Reveal direction="right">
              <motion.article
                whileHover={reduceMotion ? {} : { y: -6 }}
                className="relative h-full overflow-hidden rounded-[2rem] border border-[#dce6dc] bg-white p-7 shadow-xl sm:p-10"
              >
                <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full border-[22px] border-[#e7eee7]" />

                <span className="relative grid h-16 w-16 place-items-center rounded-2xl bg-[#fff0e8] text-[#f26322]">
                  <Eye size={32} />
                </span>

                <p className="relative mt-7 text-sm font-bold tracking-[0.18em] text-[#f26322]">
                  OUR VISION
                </p>

                <h3 className="display-font relative mt-3 text-2xl font-bold text-[#304b3c] sm:text-3xl">
                  A Trusted Leader in Cancer Care
                </h3>

                <p className="relative mt-5 text-base leading-8 text-[#526357] sm:text-lg">
                  To be a trusted leader in cancer care, advancing
                  clinical excellence, innovation and compassionate
                  treatment.
                </p>
              </motion.article>
            </Reveal>

          </div>
        </div>
      </section>

      {/* CORE VALUES */}
      <section
        id="core-values"
        className="scroll-mt-32 px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container">

          <SectionTitle
            eyebrow="WHAT GUIDES US"
            title="Our Core Values"
            description="The principles that shape how we communicate, collaborate and support patients and their families."
          />

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {values.map(({ icon: Icon, title, description }, index) => (
              <Reveal key={title} delay={index * 0.05}>
                <motion.article
                  whileHover={reduceMotion ? {} : { y: -6, scale: 1.015 }}
                  className="group h-full rounded-2xl border border-[#dfe8de] bg-white p-5 shadow-sm transition-all duration-300 hover:border-[#f26322]/60 hover:shadow-lg sm:p-6"
                >
                  <div className="flex items-center justify-between">
                    <span className="grid h-12 w-12 place-items-center rounded-xl bg-[#e7eee7] text-[#304b3c] transition-all duration-300 group-hover:bg-[#304b3c] group-hover:text-white">
                      <Icon size={23} />
                    </span>
                    <span className="text-3xl font-bold text-[#304b3c]/10">
                      0{index + 1}
                    </span>
                  </div>

                  <h3 className="display-font mt-5 text-lg font-bold text-[#304b3c] sm:text-xl">
                    {title}
                  </h3>

                  <p className="mt-3 text-sm leading-7 text-[#647368] sm:text-base">
                    {description}
                  </p>
                </motion.article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* EXCELLENCE THROUGH INCLUSION */}
      <section
        id="inclusion"
        className="scroll-mt-32 overflow-hidden bg-[#f1f5f0] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container grid items-center gap-12 lg:grid-cols-2 lg:gap-16">

          <Reveal direction="left">
            <div className="relative">
              <img
                src={patientCareImage}
                alt="Patient-centred care and support"
                loading="lazy"
                className="h-[300px] w-full rounded-[2rem_2rem_2rem_5rem] object-cover shadow-xl sm:h-[430px]"
              />

              <div className="absolute -bottom-5 -right-3 rounded-2xl bg-white p-4 shadow-xl sm:-right-5 sm:p-5">
                <div className="flex items-center gap-3">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#fff0e8] text-[#f26322]">
                    <Users size={24} />
                  </span>
                  <div>
                    <p className="font-bold text-[#304b3c]">
                      Every Voice Matters
                    </p>
                    <p className="text-sm text-[#647368]">
                      Respect. Understanding. Inclusion.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal direction="right">
            <span className="text-sm font-bold tracking-[0.17em] text-[#f26322]">
              EXCELLENCE THROUGH INCLUSION
            </span>

            <h2 className="display-font mt-3 text-3xl font-bold leading-tight text-[#304b3c] sm:text-4xl lg:text-5xl">
              Different Perspectives,
              <span className="block text-[#f26322]">
                One Shared Goal
              </span>
            </h2>

            <p className="mt-6 text-base leading-8 text-[#526357] sm:text-lg">
              At RENOVA Cancer Hospital, we believe that excellence
              in cancer care comes from respecting individual differences,
              valuing diverse perspectives and working together towards
              a shared goal.
            </p>

            <p className="mt-4 text-base leading-8 text-[#526357] sm:text-lg">
              We strive to create a supportive environment where every
              patient and family feels heard, respected and included
              throughout their cancer care journey.
            </p>

            <div className="mt-7 space-y-4">
              {[
                "Respecting individual differences",
                "Valuing diverse perspectives",
                "Listening to patients and families",
                "Working together towards better-informed care",
              ].map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <CheckCircle2
                    size={21}
                    className="mt-1 shrink-0 text-[#f26322]"
                  />
                  <p className="text-base font-semibold text-[#304b3c]">
                    {item}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ONE RENOVA */}
      <section
        id="one-renova"
        className="scroll-mt-32 px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container">

          <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#243c30] to-[#496c54] px-6 py-12 shadow-xl sm:px-10 sm:py-16 lg:px-16 lg:py-20">

            <div className="absolute -right-16 -top-20 h-64 w-64 rounded-full border-[35px] border-white/[0.06]" />
            <div className="absolute -bottom-24 left-[20%] h-64 w-64 rounded-full bg-[#f26322]/10 blur-3xl" />

            <Reveal>
              <div className="relative mx-auto max-w-4xl text-center">

                <span className="inline-flex items-center gap-2 text-sm font-bold tracking-[0.18em] text-[#ffb38d]">
                  <Handshake size={19} />
                  ONE RENOVA
                </span>

                <h2 className="display-font mt-5 text-3xl font-bold text-white sm:text-4xl lg:text-5xl">
                  Working Together to Advance Cancer Care
                </h2>

                <p className="mt-6 text-base leading-8 text-white/85 sm:text-lg">
                  Meaningful progress in cancer care comes through
                  collaboration, clinical expertise and compassion.
                  By bringing together healthcare professionals,
                  patients and families, we aim to support informed
                  treatment decisions and personalised care at every
                  stage of the cancer journey.
                </p>

                <p className="mt-5 text-base leading-8 text-white/85 sm:text-lg">
                  Our shared commitment is to provide care that
                  respects every patient, recognises individual needs
                  and keeps wellbeing at the heart of every decision.
                </p>

                <Link
                  to="/contact"
                  className="mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-[#f26322] px-7 py-3 font-bold text-white shadow-lg transition duration-300 hover:-translate-y-1 hover:bg-[#df551a] hover:shadow-xl"
                >
                  Connect With Our Team
                  <ArrowRight size={18} />
                </Link>

              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* QUALITY & PATIENT SAFETY */}
      <section
        id="quality-safety"
        className="scroll-mt-32 bg-[#f1f5f0] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16">

          <Reveal direction="left">
            <span className="text-sm font-bold tracking-[0.17em] text-[#f26322]">
              QUALITY & PATIENT SAFETY
            </span>

            <h2 className="display-font mt-3 text-3xl font-bold leading-tight text-[#304b3c] sm:text-4xl lg:text-5xl">
              Quality and Safety Matter at Every Step
            </h2>

            <p className="mt-6 text-base leading-8 text-[#526357] sm:text-lg">
              Quality and patient safety are important considerations
              throughout the cancer care journey. Clear communication,
              careful clinical processes and attention to individual
              needs all contribute to a supportive care experience.
            </p>

            <p className="mt-4 text-base leading-8 text-[#526357] sm:text-lg">
              This section can be expanded with RENOVA's verified
              hospital quality systems, accreditation, infection-control
              practices, medication safety, radiation safety, quality
              assurance and patient-safety programmes.
            </p>

            <div className="mt-7 rounded-2xl border border-[#dce6dc] bg-white p-5">
              <div className="flex items-center gap-3">
                <ShieldCheck className="shrink-0 text-[#f26322]" size={27} />
                <p className="font-semibold leading-7 text-[#304b3c]">
                  Only verified hospital policies, certifications
                  and quality information should be published here.
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal direction="right">
            <div className="relative">
              <img
                src={diagnosticImagingImage}
                alt="Diagnostic imaging in cancer care"
                loading="lazy"
                className="h-[300px] w-full rounded-[2rem_1rem_2rem_1rem] object-cover shadow-xl sm:h-[420px]"
              />

              <div className="absolute -bottom-5 -left-3 rounded-2xl border border-[#dce6dc] bg-white p-5 shadow-lg sm:-left-6">
                <div className="flex items-center gap-3">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-[#e7eee7] text-[#304b3c]">
                    <ClipboardCheck size={25} />
                  </span>
                  <div>
                    <p className="font-bold text-[#304b3c]">
                      Patient Safety
                    </p>
                    <p className="text-sm text-[#647368]">
                      A priority throughout care
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

        </div>
      </section>

      {/* TECHNOLOGY & INNOVATION */}
      <section
        id="technology"
        className="scroll-mt-32 px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container grid items-center gap-12 lg:grid-cols-2 lg:gap-16">

          <Reveal direction="left">
            <div className="relative">
              <img
                src={treatmentImage}
                alt="Cancer treatment and clinical care"
                loading="lazy"
                className="h-[300px] w-full rounded-[2rem_2rem_2rem_5rem] object-cover shadow-xl sm:h-[430px]"
              />
              <div className="absolute -right-3 -top-3 h-24 w-24 rounded-tr-[2.5rem] border-r-4 border-t-4 border-[#f26322] sm:-right-5 sm:-top-5 sm:h-32 sm:w-32" />
            </div>
          </Reveal>

          <Reveal direction="right">
            <span className="text-sm font-bold tracking-[0.17em] text-[#f26322]">
              TECHNOLOGY & INNOVATION
            </span>

            <h2 className="display-font mt-3 text-3xl font-bold leading-tight text-[#304b3c] sm:text-4xl lg:text-5xl">
              Supporting Progress in Cancer Care
            </h2>

            <p className="mt-6 text-base leading-8 text-[#526357] sm:text-lg">
              Technology and innovation continue to shape cancer
              diagnosis and treatment. Appropriate diagnostic tools,
              treatment technologies and clinical developments can
              support specialists in evaluating individual patient
              needs and discussing suitable care options.
            </p>

            <p className="mt-4 text-base leading-8 text-[#526357] sm:text-lg">
              RENOVA's verified technology portfolio can be introduced
              here at a high level, with detailed information about
              available equipment and services presented in the
              Technology & Equipment section under Cancer Care Services.
            </p>

            <Link
              to="/services"
              className="group mt-7 inline-flex min-h-12 items-center gap-2 rounded-full bg-[#304b3c] px-7 py-3 font-bold text-white transition duration-300 hover:-translate-y-1 hover:bg-[#3d5a47] hover:shadow-lg"
            >
              Explore Cancer Care Services
              <ArrowRight
                size={18}
                className="transition-transform group-hover:translate-x-1"
              />
            </Link>
          </Reveal>

        </div>
      </section>

      {/* LOCATIONS */}
      <section
        id="locations"
        className="scroll-mt-32 bg-[#f1f5f0] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24"
      >
        <div className="page-container">

          <SectionTitle
            eyebrow="FIND RENOVA"
            title="Locations"
            description="Connect with our team for information about RENOVA Cancer Hospital locations, appointments and available patient services."
          />

          <Reveal>
            <div className="mx-auto mt-10 grid max-w-5xl overflow-hidden rounded-[2rem] border border-[#dce6dc] bg-white shadow-lg md:grid-cols-2">

              <div className="relative min-h-[250px] overflow-hidden sm:min-h-[330px]">
                <img
                  src={patientCareImage}
                  alt="RENOVA patient care"
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#243c30]/70 to-transparent" />
                <div className="absolute bottom-6 left-6 text-white">
                  <Building2 size={30} className="mb-3 text-[#ffb38d]" />
                  <h3 className="display-font text-2xl font-bold text-white">
                    RENOVA Cancer Hospital
                  </h3>
                  <p className="mt-2 text-sm text-white/85">
                    Specialist cancer care and patient support
                  </p>
                </div>
              </div>

              <div className="flex flex-col justify-center p-7 sm:p-10">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#e7eee7] text-[#304b3c]">
                  <MapPin size={27} />
                </span>

                <h3 className="display-font mt-5 text-2xl font-bold text-[#304b3c]">
                  Get in Touch
                </h3>

                <p className="mt-3 text-base leading-8 text-[#647368]">
                  For current hospital addresses, directions,
                  appointment availability and location-specific
                  information, please contact the RENOVA team.
                </p>

                <Link
                  to="/contact"
                  className="mt-7 inline-flex min-h-12 w-fit items-center gap-2 rounded-full bg-[#f26322] px-7 py-3 font-bold text-white transition duration-300 hover:-translate-y-1 hover:bg-[#df551a]"
                >
                  <Phone size={17} />
                  Contact RENOVA
                  <ArrowRight size={17} />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* BOTTOM CTA */}
      <section className="px-5 py-16 sm:px-8 sm:py-20 lg:px-12">
        <div className="page-container">
          <Reveal>
            <div className="relative overflow-hidden rounded-[2rem] bg-[#304b3c] px-6 py-10 text-center shadow-xl sm:px-12 sm:py-14">

              <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full border-[28px] border-white/[0.06]" />

              <h2 className="display-font relative text-2xl font-bold text-white sm:text-3xl lg:text-4xl">
                Your Care Journey Matters
              </h2>

              <p className="relative mx-auto mt-4 max-w-2xl text-base leading-8 text-white/80 sm:text-lg">
                Reach out to our team for guidance about appointments,
                breast care services and the next steps in your care journey.
              </p>

              <Link
                to="/appointments"
                className="relative mt-7 inline-flex min-h-12 items-center gap-2 rounded-full bg-[#f26322] px-8 py-3 font-bold text-white transition duration-300 hover:-translate-y-1 hover:bg-[#df551a] hover:shadow-lg"
              >
                Book an Appointment
                <ArrowRight size={18} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

    </main>
  );
}












// import { motion, useReducedMotion } from "framer-motion";
// import {
//   HeartHandshake,
//   ShieldCheck,
//   Sparkles,
//   Flag,
//   Eye,
//   Compass,
//   Stethoscope,
//   ClipboardCheck,
//   MessagesSquare,
//   ArrowUpRight,
// } from "lucide-react";
// import { Link } from "react-router-dom";

// // import { PageLayout } from "../components/PageChrome";
// import SectionTitle from "../components/SectionTitle";
// import WaveDivider from "../components/WaveDivider";
// import TestimonialsSlider from "../components/TestimonialsSlider";
// import VideoSlider from "../components/VideoSlider";
// import PhotoGallery from "../components/PhotoGallery";

// const reasons = [
//   {
//     icon: HeartHandshake,
//     title: "Compassionate support",
//     text: "We value listening, respectful conversations and support for patients and their families.",
//   },
//   {
//     icon: ShieldCheck,
//     title: "Clear information",
//     text: "Understanding tests and treatment choices can help patients take part in informed discussions with their care team.",
//   },
//   {
//     icon: Sparkles,
//     title: "Personalised guidance",
//     text: "Breast cancer care depends on the individual diagnosis, clinical findings and the recommendations of qualified specialists.",
//   },
// ];

// const approach = [
//   {
//     icon: Flag,
//     title: "Our Mission",
//     text: "To make breast health information easier to understand and encourage timely professional assessment, informed conversations and respectful support throughout the care journey.",
//   },
//   {
//     icon: Eye,
//     title: "Our Vision",
//     text: "A care experience where every patient feels listened to, understands the next steps and has access to clear information and appropriate professional guidance.",
//   },
// ];

// const steps = [
//   {
//     icon: MessagesSquare,
//     number: "01",
//     title: "Listen and understand",
//     text: "Understand the patient's concerns, questions and relevant medical history with the healthcare team.",
//   },
//   {
//     icon: Stethoscope,
//     number: "02",
//     title: "Assessment and diagnosis",
//     text: "Clinical assessment and appropriate investigations help specialists understand changes or symptoms.",
//   },
//   {
//     icon: ClipboardCheck,
//     number: "03",
//     title: "Discuss the options",
//     text: "When results are available, the care team explains the diagnosis and discusses suitable next steps and treatment options.",
//   },
//   {
//     icon: HeartHandshake,
//     number: "04",
//     title: "Ongoing care and support",
//     text: "Follow-up, recovery guidance and supportive care can help patients navigate the next stages of their journey.",
//   },
// ];

// export default function AboutPage() {
//   const reduceMotion = useReducedMotion();

//   const reveal = (direction = 0) => ({
//     initial: {
//       opacity: 0,
//       y: reduceMotion ? 0 : 20,
//       x: reduceMotion ? 0 : direction,
//     },
//     whileInView: { opacity: 1, y: 0, x: 0 },
//     viewport: { once: true, amount: 0.15 },
//     transition: { duration: 0.55 },
//   });

      
// return (
//   <>
//     <main className="min-h-screen overflow-hidden bg-[#fffdf9] text-[#304b3c]">
//       {/* BREADCRUMB - SAME STRUCTURE AS CONTACT PAGE */}
//       <nav
//         aria-label="Breadcrumb"
//         className="border-b border-[#e5e9e3] bg-[#f7f9f6]"
//       >
//         <div className="page-container px-5 py-4 sm:px-8 lg:px-12">
//           <ol className="flex items-center gap-2 text-[15px]">
//             <li>
//               <Link
//                 to="/"
//                 className="font-medium text-[#476b55] transition-colors hover:text-[#f26322]"
//               >
//                 Home
//               </Link>
//             </li>

//             <li className="text-[#aab5aa]" aria-hidden="true">
//               /
//             </li>

//             <li
//               aria-current="page"
//               className="font-semibold text-[#263c30]"
//             >
//               About Us
//             </li>
//           </ol>
//         </div>
//       </nav>

// <div className="page-container mx-auto w-full px-5 sm:px-8 lg:px-12">
//       {/* ABOUT PAGE HEADING */}
//       <section className="mx-auto w-full max-w-7xl px-5 pt-10 text-center sm:px-8 sm:pt-12 lg:px-12">
//         <p className="text-sm font-bold tracking-[0.18em] text-[#f26322]">
//           ABOUT US
//         </p>

//         <h1 className="display-font mx-auto mt-3 max-w-3xl text-3xl font-bold leading-tight text-[#304b3c] sm:text-4xl lg:text-5xl">
//           Care that puts people first
//         </h1>

//         <p className="mx-auto mt-4 max-w-2xl text-[16px] leading-7 text-[#304b3c]">
//           Learn about our approach to breast health information, compassionate
//           support and informed conversations.
//         </p>
//       </section>

//       {/* KEEP YOUR EXISTING WHO WE ARE SECTION BELOW */}

//         {/* WHO WE ARE */}
//         <section className=" mt-10 grid items-center gap-10 lg:grid-cols-2 lg:gap-14">
//           <motion.div {...reveal(-18)} className="relative">
//             {/* <div className="absolute -left-3 -top-3 h-24 w-24 rounded-tl-[2.5rem] border-l-4 border-t-4 border-[#f26322]/70" /> */}

//             <img
//               src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1100&q=85"
//               alt="Healthcare professional speaking with a patient"
//               loading="lazy"
//               className="relative h-[280px] w-full rounded-[2rem] object-cover shadow-md transition-transform duration-500 hover:scale-[1.01] sm:h-[390px]"
//             />

//             <div className="absolute -bottom-5 right-3 max-w-[250px] rounded-2xl border border-[#e1e9df] bg-white p-4 shadow-lg sm:-right-3 sm:p-5">
//               <div className="flex items-center gap-3">
//                 <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#e7eee7] text-[#304b3c]">
//                   <HeartHandshake size={24} />
//                 </span>
//                 <div>
//                   <p className="font-bold text-[#304b3c]">Care with dignity</p>
//                   <p className="mt-1 text-sm text-[#425b4c]">
//                     Information, understanding and support
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>

//           <motion.div {...reveal(18)} className="pt-3 lg:pt-0">
//             <SectionTitle
//               center={false}
//               eyebrow="WHO WE ARE"
//               title="A more informed approach to breast care"
//               description="Breast health concerns can raise many questions. Our goal is to make information easier to understand and help patients feel prepared to discuss their concerns with qualified healthcare professionals."
//             />

//             <p className="mt-4 text-[16px] leading-8 text-[#304b3c]">
//               From recognising changes and understanding diagnostic tests
//               to discussing treatment and recovery, each step deserves
//               clear explanations, respectful conversations and appropriate
//               clinical guidance.
//             </p>

//             <Link
//               to="/contact"
//               className="group mt-6 inline-flex items-center gap-2 rounded-full bg-[#304b3c] px-6 py-3 font-semibold text-white transition duration-300 hover:-translate-y-0.5 hover:bg-[#3D5A47] hover:shadow-md"
//             >
//               Contact Us
//               <ArrowUpRight
//                 size={18}
//                 className="transition-transform group-hover:translate-x-1"
//               />
//             </Link>
//           </motion.div>
//         </section>

//         {/* WHY RENOVA */}
//         <section className="mt-20 sm:mt-24">
//           <SectionTitle
//             eyebrow="WHY RENOVA"
//             title="Care that puts people first"
//             description="Supportive communication and individualised guidance help patients understand their care journey."
//           />

//           <div className="mt-9 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
//             {reasons.map(({ icon: Icon, title, text }, index) => (
//               <motion.article
//                 key={title}
//                 {...reveal()}
//                 transition={{
//                   duration: 0.5,
//                   delay: reduceMotion ? 0 : index * 0.1,
//                 }}
//                 whileHover={reduceMotion ? {} : { y: -5 }}
//                 className="group rounded-3xl border border-[#dfe8de] bg-[#fffdf9] p-6 shadow-sm transition-all duration-300 hover:border-[#f26322]/50 hover:shadow-lg sm:p-7"
//               >
//                 <span className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#e7eee7] text-[#304b3c] transition-colors duration-300 group-hover:bg-[#304b3c] group-hover:text-white">
//                   <Icon size={27} />
//                 </span>

//                 <h3 className="display-font text-xl font-semibold text-[#304b3c]">
//                   {title}
//                 </h3>

//                 <p className="mt-3 text-[16px] leading-7 text-[#304b3c]">
//                   {text}
//                 </p>

//                 {/* <div className="mt-6 h-1 w-12 rounded-full bg-[#f26322] transition-all duration-300 group-hover:w-20" /> */}
//               </motion.article>
//             ))}
//           </div>
//         </section>

//         {/* OUR APPROACH: MISSION + VISION */}
//         <section className="mt-20 sm:mt-24">
//         {/* <section className="mt-20 rounded-[2rem] border border-[#dfe8de] bg-[#f7f9f6] p-6 sm:mt-24 sm:p-10 lg:p-12"> */}
//           <SectionTitle
//             eyebrow="OUR APPROACH"
//             title="Guided by purpose and compassion"
//             description="Our mission and vision reflect the experience we want patients to have when seeking breast health information and support."
//           />

//           <div className="mt-9 grid gap-5 md:grid-cols-2">
//             {approach.map(({ icon: Icon, title, text }, index) => (
//               <motion.article
//                 key={title}
//                 {...reveal(index === 0 ? -12 : 12)}
//                 className="rounded-3xl border border-[#dfe8de] bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md sm:p-8"
//               >
//                 <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#304b3c] text-white">
//                   <Icon size={27} />
//                 </span>

//                 <h3 className="display-font mt-5 text-2xl font-semibold text-[#304b3c]">
//                   {title}
//                 </h3>

//                 <p className="mt-3 text-[16px] leading-8 text-[#304b3c]">
//                   {text}
//                 </p>
//               </motion.article>
//             ))}
//           </div>
//         </section>

//         {/* HOW WE WORK */}
//         <section className="mt-20 sm:mt-24">
//           <SectionTitle
//             eyebrow="HOW WE WORK"
//             title="Clear steps, thoughtful conversations"
//             description="Every patient's situation is different. The steps below describe a general care journey; actual assessment and treatment depend on clinical advice."
//           />

//           <div className="relative mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
//             {steps.map(({ icon: Icon, number, title, text }, index) => (
//               <motion.article
//                 key={number}
//                 {...reveal()}
//                 transition={{
//                   duration: 0.5,
//                   delay: reduceMotion ? 0 : index * 0.08,
//                 }}
//                 whileHover={reduceMotion ? {} : { y: -4 }}
//                 className="relative rounded-3xl border border-[#dfe8de] bg-white p-6 shadow-sm transition-shadow duration-300 hover:shadow-md"
//               >
//                 <div className="flex items-center justify-between">
//                   <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#e7eee7] text-[#304b3c]">
//                     <Icon size={24} />
//                   </span>
//                   <span className="text-3xl font-bold text-[#304b3c]/10">
//                     {number}
//                   </span>
//                 </div>

//                 <h3 className="display-font mt-5 text-lg font-semibold text-[#304b3c]">
//                   {title}
//                 </h3>

//                 <p className="mt-3 text-[15px] leading-7 text-[#304b3c]">
//                   {text}
//                 </p>

//                 {/* <div className="mt-5 h-1 w-10 rounded-full bg-[#f26322]" /> */}
//               </motion.article>
//             ))}
//           </div>
//         </section>
//         </div>
//      </main>

//       {/* KEEP THE EXISTING ABOUT-PAGE SECTIONS */}
//       <WaveDivider from="#FFFFFF" to="#F6F9F6" />
//       <TestimonialsSlider />
//       <VideoSlider />
//       <PhotoGallery />
//     </>
//   );
// }






 