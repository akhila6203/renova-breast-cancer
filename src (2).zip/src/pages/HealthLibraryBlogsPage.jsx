
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { healthBlogs, healthCategories } from "../data/healthLibraryData";
import BlogCard from "../components/health-library/BlogCard";

export default function HealthLibraryBlogsPage() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredBlogs = useMemo(() => {
    return healthBlogs.filter(blog => {
      const matchesSearch =
        blog.title.toLowerCase().includes(search.toLowerCase()) ||
        blog.excerpt.toLowerCase().includes(search.toLowerCase());

      const matchesCategory =
        selectedCategory === "all" ||
        blog.categorySlug === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [search, selectedCategory]);

  return (
    <main className="min-h-screen bg-white">
      <section className="bg-[#f1f7fa] py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Link to="/">Home</Link>
            <span>/</span>
            <Link to="/health-library">Health Library</Link>
            <span>/</span>
            <span className="text-[#23658a]">Blogs</span>
          </div>

          <div className="mx-auto mt-12 max-w-3xl text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-700">
              RENOVA HEALTH LIBRARY
            </span>
            <h1 className="mt-3 text-4xl font-bold text-[#173b56] sm:text-5xl">
              Health Library Blogs
            </h1>
            <p className="mt-4 leading-7 text-slate-600">
              Explore helpful articles about cancer, diagnosis, treatments,
              prevention and survivorship.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="mb-9 flex flex-col gap-4 sm:flex-row">
          <label className="flex min-h-12 flex-1 items-center gap-3 rounded-md border border-slate-200 px-4">
            <Search size={19} className="text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={event => setSearch(event.target.value)}
              placeholder="Search health articles..."
              className="w-full bg-transparent text-sm outline-none"
            />
          </label>

          <select
            value={selectedCategory}
            onChange={event => setSelectedCategory(event.target.value)}
            className="min-h-12 rounded-md border border-slate-200 bg-white px-4 text-sm text-slate-700 outline-none focus:border-teal-600"
          >
            <option value="all">All Categories</option>
            {healthCategories.map(category => (
              <option key={category.slug} value={category.slug}>
                {category.title}
              </option>
            ))}
          </select>
        </div>

        <p className="mb-5 text-sm text-slate-500">
          Showing {filteredBlogs.length} articles
        </p>

        {filteredBlogs.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredBlogs.map(blog => (
              <BlogCard key={blog.slug} blog={blog} />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center">
            <h2 className="text-2xl font-bold text-[#173b56]">
              No articles found
            </h2>
            <p className="mt-3 text-slate-500">
              Try another search or select a different category.
            </p>
          </div>
        )}
      </section>
    </main>
  );
}








// import { useMemo, useState } from "react";
// import { PageLayout } from "../components/PageChrome";
// import BlogCard from "../components/health-library/BlogCard";
// import { healthBlogs } from "../data/healthLibraryContent";

// export default function HealthLibraryBlogsPage() {
//   const [visible, setVisible] = useState(12);
//   const [query, setQuery] = useState("");
//   const filtered = useMemo(()=>healthBlogs.filter(b=>`${b.title} ${b.category}`.toLowerCase().includes(query.toLowerCase())),[query]);
//   return <PageLayout eyebrow="HEALTH LIBRARY / BLOGS" title="Cancer care articles & patient guides" description="Explore clear, patient-friendly articles about diagnosis, treatment options, supportive care and survivorship." breadcrumbItems={[{label:"Home",path:"/"},{label:"Health Library",path:"/health-library"},{label:"Blogs"}]}>
//     <div className="mb-7 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><p className="text-sm text-ink/70">{filtered.length} educational articles</p><input value={query} onChange={e=>{setQuery(e.target.value);setVisible(12)}} placeholder="Search articles..." className="w-full rounded-full border border-line px-5 py-3 text-sm outline-none focus:border-royal sm:max-w-xs"/></div>
//     <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{filtered.slice(0,visible).map(blog=><BlogCard key={blog.id} blog={blog}/>)}</div>
//     {visible<filtered.length && <div className="mt-10 text-center"><button onClick={()=>setVisible(v=>v+8)} className="btn-primary">Load more articles</button></div>}
//   </PageLayout>;
// }
