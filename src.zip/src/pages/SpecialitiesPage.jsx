
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { specialities } from "../data/specialitiesData";

export default function SpecialitiesPage() {
  const [columns, setColumns] = useState(5);
  const [visibleCount, setVisibleCount] = useState(20);

  // Responsive columns
  useEffect(() => {
    const updateLayout = () => {
      const width = window.innerWidth;

      if (width >= 1440) {
        setColumns(5);
      } else if (width >= 768) {
        setColumns(3);
      } else {
        setColumns(2);
      }
    };

    updateLayout();
    window.addEventListener("resize", updateLayout);

    return () => window.removeEventListener("resize", updateLayout);
  }, []);

  // Show four rows initially
  useEffect(() => {
    setVisibleCount(columns * 4);
  }, [columns]);

  const visibleSpecialities = specialities.slice(0, visibleCount);

  const hasMore = visibleCount < specialities.length;
  const hasLess = visibleCount > columns * 4;

  const showMore = () => {
    setVisibleCount((current) =>
      Math.min(current + columns * 2, specialities.length)
    );
  };

  const showLess = () => {
    setVisibleCount(columns * 4);
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#fffdf9] text-[#344638]">

      {/* Breadcrumb */}
      <nav
        aria-label="Breadcrumb"
        className="border-b border-[#e7ebe3] bg-[#f5f8f2]"
      >
        <div className="page-container px-5 py-3 sm:px-8 lg:px-12">
          <ol className="flex items-center gap-2 text-sm sm:text-base">
            <li>
              <Link
                to="/"
                className="font-medium text-[#e87744] transition-colors duration-300 hover:text-[#4f7359]"
              >
                Home
              </Link>
            </li>

            <li className="text-[#aab5aa]">/</li>

            <li className="font-semibold text-[#344638]">
              Specialities
            </li>
          </ol>
        </div>
      </nav>

      {/* Centered heading */}
      <section className="page-container px-5 pb-5 pt-10 text-center sm:px-8 sm:pt-14 lg:px-12">

        <span className="text-sm font-bold tracking-[0.18em] text-[#e87744]">
          OUR SPECIALITIES
        </span>

        <h1 className="mx-auto mt-3 max-w-5xl font-display text-3xl font-bold leading-tight text-[#344638] sm:text-4xl lg:text-5xl">
          Expertise Across the Cancer Journey
        </h1>

        <p className="mx-auto mt-4 max-w-3xl text-base leading-8 text-[#647368] sm:text-lg">
          The specialty pages explain who provides care and what role each clinical discipline plays.
        </p>

        <div className="mx-auto mt-5 h-1 w-28 rounded-full bg-[#e87744]" />

      </section>

      {/* Speciality Cards */}
      <section className="page-container px-5 pb-14 pt-6 sm:px-8 sm:pb-16 lg:px-12">

        <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 min-[1440px]:grid-cols-5">

          {visibleSpecialities.map((item, index) => {
            const Icon = item.Icon;

            return (
              <Link
                key={item.slug}
                to={`/specialities/${item.slug}`}
                className="
                  group relative flex min-h-[185px]
                  flex-col items-center justify-center
                  overflow-hidden rounded-xl
                  border border-[#e5eae2] bg-white
                  px-3 py-5 text-center
                  shadow-[0_2px_10px_rgba(52,70,56,0.05)]
                  transition-all duration-300
                  hover:-translate-y-1
                  hover:border-[#4f7359]
                  hover:shadow-[0_8px_20px_rgba(52,70,56,0.11)]
                  sm:min-h-[200px] sm:px-4 sm:py-6
                "
                style={{
                  animation: "fade-up 0.6s ease both",
                  animationDelay: `${(index % 10) * 70}ms`,
                }}
              >

                {/* Icon: Orange normally, Green on hover */}
                <span
                  className="
                    relative z-10 mb-4
                    grid h-[68px] w-[68px] place-items-center
                    rounded-xl
                    bg-[#edf4ec]
                    text-[#e87744]
                    transition-all duration-300
                    group-hover:scale-105
                    group-hover:bg-[#fff1e9]
                    sm:h-[74px] sm:w-[74px]
                  "
                >
                  {Icon && (
                    <Icon
                      size={42}
                      strokeWidth={1.7}
                      className="
                        text-[#e87744]
                        transition-colors duration-300
                        group-hover:text-[#4f7359]
                      "
                    />
                  )}
                </span>

                {/* Speciality name */}
                <h2
                  className="
                    relative z-10
                    max-w-full font-display
                    text-base font-semibold
                    leading-6 text-[#344638]
                    transition-colors duration-300
                    group-hover:text-[#4f7359]
                    sm:text-lg
                  "
                >
                  {item.title}
                </h2>

                {/* Explore appears only on hover */}
                <span
                  className="
                    relative z-10 mt-0
                    flex max-h-0 items-center gap-2
                    overflow-hidden
                    text-sm font-semibold text-[#e87744]
                    translate-y-2 opacity-0
                    transition-all duration-300
                    group-hover:mt-2
                    group-hover:max-h-8
                    group-hover:translate-y-0
                    group-hover:opacity-100
                  "
                >
                  Explore Speciality
                  <ArrowRight
                    size={16}
                    className="transition-transform duration-300 group-hover:translate-x-1"
                  />
                </span>

              </Link>
            );
          })}

        </div>

        {/* Show More / Show Less */}
        {specialities.length > columns * 4 && (
          <div className="mt-10 flex justify-center">

            {hasMore && (
              <button
                type="button"
                onClick={showMore}
                className="
                  inline-flex min-h-11 items-center
                  justify-center gap-2 rounded-full
                  bg-[#4f7359] px-8 py-3
                  text-sm font-bold text-white
                  shadow-sm transition-all duration-300
                  hover:-translate-y-0.5
                  hover:bg-[#3d6048] hover:shadow-md
                "
              >
                Show More
                <ArrowRight size={17} />
              </button>
            )}

            {!hasMore && hasLess && (
              <button
                type="button"
                onClick={showLess}
                className="
                  inline-flex min-h-11 items-center
                  justify-center rounded-full
                  border border-[#4f7359] bg-white
                  px-8 py-3 text-sm font-bold
                  text-[#4f7359] transition-all duration-300
                  hover:bg-[#4f7359] hover:text-white
                "
              >
                Show Less
              </button>
            )}

          </div>
        )}

      </section>
    </main>
  );
}




// import { useEffect, useState } from "react";
// import { Link } from "react-router-dom";
// import { ArrowRight } from "lucide-react";
// import { specialities } from "../data/specialitiesData";

// export default function SpecialitiesPage() {
//   const [columns, setColumns] = useState(5);
//   const [visibleCount, setVisibleCount] = useState(20);

//   // Responsive columns
//   useEffect(() => {
//     const updateLayout = () => {
//       const width = window.innerWidth;

//       if (width >= 1440) {
//         setColumns(5);
//       } else if (width >= 768) {
//         setColumns(3);
//       } else {
//         setColumns(2);
//       }
//     };

//     updateLayout();
//     window.addEventListener("resize", updateLayout);

//     return () => window.removeEventListener("resize", updateLayout);
//   }, []);

//   // Show four rows initially
//   useEffect(() => {
//     setVisibleCount(columns * 4);
//   }, [columns]);

//   const visibleSpecialities = specialities.slice(0, visibleCount);

//   const hasMore = visibleCount < specialities.length;
//   const hasLess = visibleCount > columns * 4;

//   const showMore = () => {
//     setVisibleCount((current) =>
//       Math.min(current + columns * 2, specialities.length)
//     );
//   };

//   const showLess = () => {
//     setVisibleCount(columns * 4);
//   };

//   return (
//     <main className="min-h-screen overflow-hidden bg-[#fffdf9] text-ink">

//       {/* Breadcrumb */}
//       <nav
//         aria-label="Breadcrumb"
//         className="border-b border-line bg-mist"
//       >
//         <div className="page-container px-5 py-3 sm:px-8 lg:px-12">
//           <ol className="flex items-center gap-2 text-sm sm:text-base">
//             <li>
//               <Link
//                 to="/"
//                 className="font-medium text-royal transition hover:text-sky"
//               >
//                 Home
//               </Link>
//             </li>

//             <li className="text-[#aab5aa]">/</li>

//             <li className="font-semibold text-navy">
//               Specialities
//             </li>
//           </ol>
//         </div>
//       </nav>

//       {/* Centered heading */}
//       <section className="page-container px-5 pb-5 pt-10 text-center sm:px-8 sm:pt-14 lg:px-12">

//         <span className="text-sm font-bold tracking-[0.18em] text-sky">
//           OUR SPECIALITIES
//         </span>

//         <h1 className="mx-auto mt-3 max-w-5xl font-display text-3xl font-bold leading-tight text-navy sm:text-4xl lg:text-5xl">
//           Expertise Across the Cancer Journey
//         </h1>

//         <p className="mx-auto mt-4 max-w-3xl text-base leading-8 text-[#647368] sm:text-lg">
//           The specialty pages explain who provides care and what role each clinical discipline plays.
//         </p>

//         <div className="mx-auto mt-5 h-1 w-28 rounded-full bg-[#e87744]" />

//       </section>

//       {/* Speciality Cards */}
//       <section className="page-container px-5 pb-14 pt-6 sm:px-8 sm:pb-16 lg:px-12">

//         <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 min-[1440px]:grid-cols-5">

//           {visibleSpecialities.map((item, index) => {
//   const Icon = item.Icon;

//   return (
//     <Link
//       key={item.slug}
//       to={`/specialities/${item.slug}`}
//       className="
//         group relative flex min-h-[195px]
//         flex-col items-center justify-center
//         overflow-hidden rounded-2xl
//         border border-line bg-white
//         px-3 py-6 text-center shadow-sm
//         transition-all duration-500
//         hover:-translate-y-2
//         hover:border-royal
//         hover:shadow-premium
//         sm:min-h-[215px] sm:px-4
//       "
//       style={{
//         animation: "fade-up 0.6s ease both",
//         animationDelay: `${(index % 10) * 70}ms`,
//       }}
//     >
//       {/* Original brand colour icon background */}
//       <span
//         className="
//           relative z-10 mb-4
//           grid h-20 w-20 place-items-center
//           rounded-xl bg-ice
//           text-royal
//           transition-transform duration-500
//           group-hover:scale-110
//         "
//       >
//         {Icon && (
//           <Icon
//             size={48}
//             strokeWidth={1.6}
//             className="text-royal"
//           />
//         )}
//       </span>

//       {/* Speciality name */}
//       <h2
//         className="
//           relative z-10
//           max-w-full font-display
//           text-base font-semibold
//           leading-6 text-navy
//           transition-colors duration-300
//           group-hover:text-royal
//           sm:text-lg
//         "
//       >
//         {item.title}
//       </h2>

//       {/* Explore appears only on hover */}
//       <span
//         className="
//           relative z-10 mt-0
//           flex max-h-0 items-center gap-2
//           overflow-hidden
//           text-sm font-bold text-sky
//           translate-y-2 opacity-0
//           transition-all duration-300
//           group-hover:mt-3
//           group-hover:max-h-8
//           group-hover:translate-y-0
//           group-hover:opacity-100
//         "
//       >
//         Explore Speciality
//         <ArrowRight
//           size={16}
//           className="transition-transform duration-300 group-hover:translate-x-1"
//         />
//       </span>
//     </Link>
//   );
// })}

//         </div>

//         {/* Show More / Show Less */}
//         {specialities.length > columns * 4 && (
//           <div className="mt-10 flex justify-center">

//             {hasMore && (
//               <button
//                 type="button"
//                 onClick={showMore}
//                 className="
//                   inline-flex min-h-12 items-center
//                   justify-center gap-2 rounded-full
//                   bg-royal px-8 py-3
//                   text-sm font-bold text-white
//                   shadow-sm transition-all duration-300
//                   hover:-translate-y-1
//                   hover:bg-royaldeep hover:shadow-lg
//                 "
//               >
//                 Show More
//                 <ArrowRight size={17} />
//               </button>
//             )}

//             {!hasMore && hasLess && (
//               <button
//                 type="button"
//                 onClick={showLess}
//                 className="
//                   inline-flex min-h-12 items-center
//                   justify-center rounded-full
//                   border border-royal bg-white
//                   px-8 py-3 text-sm font-bold
//                   text-royal transition-all duration-300
//                   hover:bg-royal hover:text-white
//                 "
//               >
//                 Show Less
//               </button>
//             )}

//           </div>
//         )}

//       </section>
//     </main>
//   );
// }
