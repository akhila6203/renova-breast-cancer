import { Link, Navigate, useParams } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  MapPin,
  BriefcaseMedical,
  CalendarDays,
  Stethoscope,
  HeartHandshake,
} from "lucide-react";

import { getSpecialityBySlug, getRelatedSpecialities } from "../data/specialitiesData";
import { doctors } from "../data/doctorsData";

export default function SpecialityDetailPage() {
  const { slug } = useParams();
  const reduceMotion = useReducedMotion();

  const speciality = getSpecialityBySlug(slug);

  if (!speciality) {
    return <Navigate to="/specialities" replace />;
  }

  const Icon = speciality.Icon;
  const relatedSpecialities = getRelatedSpecialities(speciality);

  // Show only doctors whose speciality matches this page.
  const specialityDoctors = doctors.filter(
    (doctor) => doctor.speciality === speciality.title
  );

  // Use testimonials belonging to the matching doctors.
  const patientTestimonials = specialityDoctors.flatMap((doctor) =>
    (doctor.testimonials || []).map((testimonial, index) => ({
      ...testimonial,
      id: `${doctor.id}-${index}`,
      doctorName: doctor.name,
    }))
  );

  const revealLeft = {
    hidden: { opacity: 0, x: reduceMotion ? 0 : -35 },
    visible: { opacity: 1, x: 0 },
  };

  const revealRight = {
    hidden: { opacity: 0, x: reduceMotion ? 0 : 35 },
    visible: { opacity: 1, x: 0 },
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#fffdf9] text-ink">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="border-b border-line bg-mist">
        <div className="page-container px-5 py-3 sm:px-8 lg:px-12">
          <ol className="flex flex-wrap items-center gap-2 text-sm sm:text-base">
            <li>
              <Link to="/" className="font-semibold text-royal hover:text-sky">
                Home
              </Link>
            </li>
            <li className="text-[#aab5aa]">/</li>
            <li>
              <Link
                to="/specialities"
                className="font-semibold text-royal hover:text-sky"
              >
                Specialities
              </Link>
            </li>
            <li className="text-[#aab5aa]">/</li>
            <li className="font-semibold text-navy">{speciality.title}</li>
          </ol>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#e8f0ea] via-[#f8faf8] to-[#fff3ec] px-5 py-12 sm:px-8 sm:py-16 lg:px-12">
        <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full bg-white/70 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-20 h-72 w-72 rounded-full bg-[#f5d9c8]/40 blur-3xl" />

        <div className="page-container relative grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_300px]">
          <motion.div
            variants={revealLeft}
            initial="hidden"
            animate="visible"
            transition={{ duration: reduceMotion ? 0 : 0.65 }}
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-[#d4e0d6] bg-white/80 px-4 py-2 text-xs font-bold tracking-[0.16em] text-royal sm:text-sm">
              RENOVA SPECIALIST CARE
            </span>

            <h1 className="mt-5 max-w-3xl font-display text-3xl font-bold leading-tight text-navy sm:text-4xl lg:text-5xl">
              {speciality.title}
            </h1>

            <h2 className="mt-4 max-w-3xl text-xl font-bold leading-snug text-royal sm:text-2xl">
              {speciality.heading}
            </h2>

            <p className="mt-4 max-w-3xl text-base leading-8 text-[#526357] sm:text-lg">
              {speciality.description}
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/appointments" className="btn-primary">
                Book an Appointment
                <ArrowRight size={17} />
              </Link>

              <Link to="/doctors" className="btn-secondary">
                Meet Our Doctors
              </Link>
            </div>
          </motion.div>

          <motion.div
            variants={revealRight}
            initial="hidden"
            animate="visible"
            transition={{ duration: reduceMotion ? 0 : 0.7, delay: 0.12 }}
            className="mx-auto grid h-52 w-52 place-items-center rounded-[2.5rem] border border-white bg-white/85 shadow-[0_20px_55px_rgba(47,70,56,0.12)] sm:h-64 sm:w-64"
          >
            <div className="grid h-36 w-36 place-items-center rounded-[2rem] bg-[#fff3ec] text-royal sm:h-44 sm:w-44">
              <Icon size={88} strokeWidth={1.35} />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Overview and care areas */}
      <section className="page-container grid gap-8 px-5 py-12 sm:px-8 sm:py-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-12 lg:px-12">
        <motion.div
          variants={revealLeft}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: reduceMotion ? 0 : 0.6 }}
          className="rounded-[1.75rem] border border-line bg-white p-6 shadow-sm sm:p-8"
        >
          <span className="text-sm font-bold tracking-[0.15em] text-sky">
            ABOUT THIS SPECIALITY
          </span>

          <h2 className="mt-3 font-display text-2xl font-bold text-navy sm:text-3xl">
            Understanding {speciality.title}
          </h2>

          <p className="mt-4 text-base leading-8 text-[#647368]">
            {speciality.description}
          </p>

          <div className="mt-7 rounded-2xl bg-ice p-5">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white text-royal">
                <HeartHandshake size={23} />
              </span>
              <h3 className="font-display text-lg font-bold text-navy">
                When to Consult
              </h3>
            </div>
            <p className="mt-3 text-sm leading-7 text-[#526357] sm:text-base">
              {speciality.whenToConsult}
            </p>
          </div>
        </motion.div>

        <motion.div
          variants={revealRight}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: reduceMotion ? 0 : 0.6 }}
          className="rounded-[1.75rem] border border-line bg-white p-6 shadow-sm sm:p-8"
        >
          <span className="text-sm font-bold tracking-[0.15em] text-sky">
            OUR CLINICAL SERVICES
          </span>

          <h2 className="mt-3 font-display text-2xl font-bold text-navy sm:text-3xl">
            Care & Treatment Areas
          </h2>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {speciality.careAreas.map((area, index) => (
              <motion.div
                key={area}
                initial={{ opacity: 0, y: reduceMotion ? 0 : 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: reduceMotion ? 0 : 0.35,
                  delay: reduceMotion ? 0 : index * 0.035,
                }}
                className="flex items-start gap-3 rounded-xl border border-[#e5ebe5] bg-[#fbfdfb] p-3 transition hover:border-royal hover:bg-ice"
              >
                <CheckCircle2
                  size={19}
                  className="mt-0.5 shrink-0 text-royal"
                />
                <span className="text-sm font-medium leading-6 text-[#405247]">
                  {area}
                </span>
              </motion.div>
            ))}
          </div>

          {speciality.note && (
            <p className="mt-5 rounded-xl border-l-4 border-sky bg-[#fff8f3] p-4 text-sm leading-7 text-[#647368]">
              {speciality.note}
            </p>
          )}
        </motion.div>
      </section>

      {/* Sub-specialities */}
      <section className="bg-mist px-5 py-12 sm:px-8 sm:py-16 lg:px-12">
        <div className="page-container">
          <div className="mx-auto max-w-3xl text-center">
            <span className="text-sm font-bold tracking-[0.15em] text-sky">
              AREAS OF FOCUS
            </span>
            <h2 className="mt-2 font-display text-2xl font-bold text-navy sm:text-3xl">
              Sub-specialities
            </h2>
            <p className="mt-3 text-base leading-7 text-[#647368]">
              Different areas of focus may be considered as part of an
              individual assessment and treatment plan.
            </p>
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {speciality.subSpecialties.map((item, index) => (
              <motion.div
                key={item}
                initial={{
                  opacity: 0,
                  x: reduceMotion ? 0 : index % 2 === 0 ? -22 : 22,
                }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: reduceMotion ? 0 : 0.45 }}
                className="flex items-center gap-3 rounded-2xl border border-line bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff3ec] text-sky">
                  <ChevronRight size={21} />
                </span>
                <h3 className="text-sm font-bold leading-6 text-navy sm:text-base">
                  {item}
                </h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Related specialities */}
      {relatedSpecialities.length > 0 && (
        <section className="page-container px-5 py-12 sm:px-8 sm:py-16 lg:px-12">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="text-sm font-bold tracking-[0.15em] text-sky">
                CONNECTED CARE
              </span>
              <h2 className="mt-2 font-display text-2xl font-bold text-navy sm:text-3xl">
                Related Specialities
              </h2>
            </div>
            <Link
              to="/specialities"
              className="inline-flex items-center gap-2 text-sm font-bold text-royal hover:text-sky"
            >
              View all
              <ArrowRight size={16} />
            </Link>
          </div>

          <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {relatedSpecialities.map((item) => {
              const RelatedIcon = item.Icon;

              return (
                <Link
                  key={item.slug}
                  to={`/specialities/${item.slug}`}
                  className="group flex items-center gap-4 rounded-2xl border border-line bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:border-royal hover:shadow-md"
                >
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-ice text-royal transition group-hover:bg-[#fff3ec] group-hover:text-sky">
                    <RelatedIcon size={29} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-bold text-navy">
                      {item.title}
                    </span>
                    <span className="mt-1 block text-sm leading-6 text-[#718075]">
                      {item.short}
                    </span>
                  </span>
                  <ArrowRight
                    size={18}
                    className="shrink-0 text-sky transition group-hover:translate-x-1"
                  />
                </Link>
              );
            })}
          </div>
        </section>
      )}

      {/* Doctors */}
      <section className="bg-[#f6f9f6] px-5 py-12 sm:px-8 sm:py-16 lg:px-12">
        <div className="page-container">
          <div className="text-center">
            <span className="text-sm font-bold tracking-[0.15em] text-sky">
              MEET THE EXPERTS
            </span>
            <h2 className="mt-2 font-display text-2xl font-bold text-navy sm:text-3xl">
              {speciality.title} Doctors
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-base leading-7 text-[#647368]">
              Meet our specialists and explore their qualifications, experience
              and areas of expertise.
            </p>
          </div>

          {specialityDoctors.length > 0 ? (
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {specialityDoctors.map((doctor, index) => (
                <motion.article
                  key={doctor.id}
                  initial={{ opacity: 0, y: reduceMotion ? 0 : 25 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: reduceMotion ? 0 : 0.5,
                    delay: reduceMotion ? 0 : index * 0.08,
                  }}
                  className="group overflow-hidden rounded-[1.5rem] border border-line bg-white shadow-sm transition duration-300 hover:-translate-y-2 hover:shadow-premium"
                >
                  <Link
                    to={`/doctors/${doctor.slug}`}
                    className="block overflow-hidden bg-ice"
                  >
                    <div className="h-[260px] overflow-hidden">
                      <img
                        src={doctor.image}
                        alt={doctor.name}
                        loading="lazy"
                        className="h-full w-full object-cover object-top transition duration-500 group-hover:scale-105"
                      />
                    </div>
                  </Link>

                  <div className="p-5">
                    <h3 className="font-display text-lg font-bold text-navy">
                      {doctor.name}
                    </h3>
                    <p className="mt-1 text-sm font-semibold text-royal">
                      {doctor.designation}
                    </p>

                    <div className="mt-4 space-y-2 text-sm text-[#647368]">
                      <p className="flex items-start gap-2">
                        <BriefcaseMedical
                          size={16}
                          className="mt-0.5 shrink-0 text-royal"
                        />
                        {doctor.experience}+ Years Experience
                      </p>
                      <p className="flex items-start gap-2">
                        <MapPin
                          size={16}
                          className="mt-0.5 shrink-0 text-royal"
                        />
                        {doctor.location}
                      </p>
                    </div>

                    <div className="mt-5 flex flex-wrap gap-2">
                      <Link
                        to={`/doctors/${doctor.slug}`}
                        className="btn-secondary min-h-10 flex-1 px-3 py-2 text-sm"
                      >
                        View Profile
                        <ArrowRight size={15} />
                      </Link>
                      <Link
                        to={`/appointments?doctor=${encodeURIComponent(doctor.name)}`}
                        className="btn-primary min-h-10 flex-1 px-3 py-2 text-sm"
                      >
                        Book
                      </Link>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          ) : (
            <div className="mt-8 rounded-2xl border border-line bg-white px-6 py-10 text-center">
              <Stethoscope size={38} className="mx-auto text-royal" />
              <h3 className="mt-3 font-display text-xl font-bold text-navy">
                Specialist profiles will be updated
              </h3>
              <p className="mx-auto mt-2 max-w-xl text-sm leading-7 text-[#647368]">
                Please contact our team to enquire about specialists and
                appointments for this department.
              </p>
              <Link to="/appointments" className="btn-primary mt-5">
                Enquire for an Appointment
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Patient testimonials */}
      <section className="page-container px-5 py-12 sm:px-8 sm:py-16 lg:px-12">
        <div className="text-center">
          <span className="text-sm font-bold tracking-[0.15em] text-sky">
            PATIENT EXPERIENCES
          </span>
          <h2 className="mt-2 font-display text-2xl font-bold text-navy sm:text-3xl">
            Patient Testimonials
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-base leading-7 text-[#647368]">
            Feedback shared about care experiences with this speciality team.
          </p>
        </div>

        {patientTestimonials.length > 0 ? (
          <>
            <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {patientTestimonials.map((item, index) => (
                <motion.blockquote
                  key={item.id}
                  initial={{ opacity: 0, y: reduceMotion ? 0 : 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: reduceMotion ? 0 : 0.45,
                    delay: reduceMotion ? 0 : index * 0.06,
                  }}
                  className="relative rounded-[1.5rem] border border-line bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-md"
                >
                  <span className="absolute right-5 top-2 font-serif text-6xl leading-none text-[#f5d9c8]">
                    “
                  </span>
                  <p className="relative z-10 text-base leading-8 text-[#526357]">
                    {item.quote}
                  </p>
                  <footer className="mt-5 border-t border-line pt-4">
                    <p className="font-bold text-navy">{item.name}</p>
                    <p className="mt-1 text-xs text-[#718075]">
                      {item.detail}
                    </p>
                    <p className="mt-2 text-xs font-semibold text-royal">
                      {item.doctorName}
                    </p>
                  </footer>
                </motion.blockquote>
              ))}
            </div>

            <p className="mt-5 text-center text-xs leading-6 text-[#87958a]">
              Patient feedback shown here is sample content from the current
              project data. Publish only verified patient feedback with
              appropriate consent.
            </p>
          </>
        ) : (
          <div className="mt-8 rounded-2xl border border-line bg-mist p-8 text-center">
            <p className="text-sm leading-7 text-[#647368]">
              Patient stories for this speciality will be added after approved
              feedback is available.
            </p>
          </div>
        )}
      </section>

      {/* Appointment CTA */}
      <section className="px-5 pb-14 sm:px-8 lg:px-12">
        <div className="page-container rounded-[2rem] bg-gradient-to-r from-[#2f4638] to-[#4f7359] px-6 py-9 text-center shadow-lg sm:px-10 sm:py-12">
          <CalendarDays size={34} className="mx-auto text-[#f0b08a]" />
          <h2 className="mt-3 font-display text-2xl font-bold text-white sm:text-3xl">
            Take the next step in your care
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-white/85 sm:text-base">
            Speak with our team to understand appointment options for{" "}
            {speciality.title}.
          </p>
          <Link
            to="/appointments"
            className="mt-6 inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-white px-7 py-3 text-sm font-bold text-royal transition hover:-translate-y-1 hover:bg-[#fff3ec]"
          >
            Book an Appointment
            <ArrowRight size={17} />
          </Link>
        </div>
      </section>
    </main>
  );
}